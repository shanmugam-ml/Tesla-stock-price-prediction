# Tesla Stock Price Forecasting Using LSTM

A production-grade, end-to-end Deep Learning application that retrieves authentic historical Tesla Inc. (**TSLA**) market data, preprocesses sequential time-series windows, trains a two-layer Long Short-Term Memory (LSTM) recurrent neural network in TensorFlow/Keras, and forecasts the next trading day's closing price through an interactive fintech analytics dashboard.

---

## 1. Project Title
**Tesla Stock Price Forecasting Using LSTM**

## 2. Project Overview
This project provides a complete deep learning workflow for financial time-series forecasting. It integrates Yahoo Finance data retrieval (`yfinance`), leak-free chronological preprocessing, a 2-layer LSTM deep learning architecture, quantitative model evaluation (MAE, MSE, RMSE) benchmarked against persistence baselines, and a modern Streamlit dashboard for financial researchers, students, and engineers.

## 3. Abstract
Financial market price prediction represents a quintessential time-series modeling problem characterized by non-linearity, regime shifts, and non-stationarity. In this project, an LSTM neural network is implemented to ingest the previous 60 consecutive trading days of TSLA closing prices to forecast the subsequent trading day's close. Chronological data splitting (70% Train, 15% Validation, 15% Test) and training-only scaler normalization guarantee that no future information leaks into the model. The trained network achieves lower prediction error than traditional moving average heuristics and provides transparent evaluation metrics.

## 4. Problem Statement
Stock prices do not follow independent, identically distributed (i.i.d.) random variables. Traditional linear regression and classical ARIMA models struggle with sudden volatility shifts and non-linear momentum cycles. Conversely, recurrent neural architectures with gated memory units can learn sequential patterns over rolling temporal windows. The core objective is predicting $y_{t+1}$ given sequence $[y_{t-59}, y_{t-58}, \dots, y_t]$.

## 5. Project Objectives
- Automate authentic historical Tesla stock market data acquisition via Yahoo Finance API.
- Support fallback ingestion through custom user-uploaded CSV files.
- Enforce strict chronological data integrity (no random shuffling, zero lookahead bias).
- Formulate 60-day sliding window sequences for LSTM temporal processing.
- Build and train a 2-layer stacked LSTM neural network with early stopping and model checkpointing.
- Perform empirical evaluation using USD-scale MAE, MSE, and RMSE.
- Benchmark LSTM performance against a Naive Persistence Baseline ($y_{t+1} = y_t$).
- Deploy an interactive, high-contrast dark fintech terminal dashboard with Plotly charts.

## 6. Technologies Used
- **Programming Language**: Python 3.10+
- **Deep Learning Framework**: TensorFlow 2.x & Keras 3.x
- **Time-Series Models**: Long Short-Term Memory (LSTM) Recurrent Neural Network
- **Data Engineering**: Pandas, NumPy, Scikit-learn (`MinMaxScaler`)
- **Data Ingestion**: `yfinance` (Yahoo Finance API)
- **Interactive UI**: Streamlit
- **Data Visualization**: Plotly, Matplotlib, Seaborn
- **Testing**: Pytest

## 7. Dataset Source
Historical stock market data is retrieved from Yahoo Finance for ticker **TSLA** (Tesla, Inc. listed on NASDAQ). The default window spans from **2015-01-01** to the present date, encompassing over 2,900 authentic trading sessions covering market expansions, stock splits, volatility spikes, and contemporary macro regimes.

## 8. Dataset Features
- **Date**: Calendar date of the trading session (YYYY-MM-DD format).
- **Open**: Opening price of TSLA shares at 09:30 AM EST (USD).
- **High**: Highest traded price during the trading session (USD).
- **Low**: Lowest traded price during the session (USD).
- **Close**: Final official closing price at 04:00 PM EST (USD) — **Primary Target Variable**.
- **Volume**: Total number of shares transacted throughout the day.

## 9. Data Preprocessing Techniques
1. **Deduplication**: Identification and removal of duplicate session timestamps.
2. **Missing Value Imputation & Scrubbing**: Filtering out non-trading sessions and holiday nulls.
3. **Chronological Sorting**: Sorting records monotonically from oldest to newest.
4. **Leak-Free Chronological Splitting**:
   - 70% Training set
   - 15% Validation set
   - 15% Testing set (strictly unseen chronological future)
5. **Feature Scaling**: `MinMaxScaler(feature_range=(0, 1))` fitted exclusively on the training partition.
6. **Sequential Sliding Windows**: Input shape $(N, 60, 1)$ paired with output $(N, 1)$.
7. **USD Inversion**: Transforming scaled outputs back into original US Dollars using `scaler.inverse_transform()`.

## 10. LSTM Architecture
```
Input Sequence [Shape: (60, 1)]
       │
       ▼
┌──────────────────────────────────────────────┐
│  LSTM Layer 1 (50 units, return_seq=True)    │  Captures multi-scale temporal dependencies
└──────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────┐
│  LSTM Layer 2 (50 units, return_seq=False)   │  Compresses recurrent sequence into hidden vector
└──────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────┐
│  Dense Layer (25 units, activation='relu')   │  Non-linear feature projection
└──────────────────────────────────────────────┘
       │
       ▼
┌──────────────────────────────────────────────┐
│  Output Layer (1 unit, activation='linear')  │  Next Trading Day Forecast (USD)
└──────────────────────────────────────────────┘
```

## 11. Training Configuration
- **Loss Function**: Mean Squared Error (MSE)
- **Optimizer**: Adam (learning rate = 0.001)
- **Batch Size**: 32 (configurable 16–128)
- **Epochs**: 50 (with EarlyStopping, patience=10)
- **Callbacks**: `ModelCheckpoint(filepath="models/lstm_model.keras", save_best_only=True)`
- **Reproducibility**: Global seed initialization across `random`, `numpy`, and `tensorflow`.

## 12. Model Evaluation Methods
Evaluations are conducted on the chronological out-of-sample test set using unscaled USD values:
- **Mean Absolute Error (MAE)**:
  $$\text{MAE} = \frac{1}{n} \sum_{i=1}^{n} |y_i - \hat{y}_i|$$
- **Mean Squared Error (MSE)**:
  $$\text{MSE} = \frac{1}{n} \sum_{i=1}^{n} (y_i - \hat{y}_i)^2$$
- **Root Mean Squared Error (RMSE)**:
  $$\text{RMSE} = \sqrt{\frac{1}{n} \sum_{i=1}^{n} (y_i - \hat{y}_i)^2}$$
- **Persistence Benchmark**: Comparing against the Random Walk / Naive forecast ($y_{t+1} = y_t$).

## 13. Project Folder Structure
```
Tesla_Stock_Forecasting/
├── app.py                     # Main Streamlit dashboard application
├── config.py                  # Global hyperparameters, paths, and styling settings
├── requirements.txt           # Python dependency specifications
├── README.md                  # Comprehensive documentation
├── .gitignore                 # Version control exclusions
│
├── data/
│   └── tesla_stock.csv        # Historical TSLA dataset (2015-present)
│
├── models/
│   ├── lstm_model.keras       # Trained Keras sequential model
│   └── training_history.json  # Saved epoch loss records
│
├── src/
│   ├── __init__.py
│   ├── data_collection.py     # Yahoo Finance API & CSV validation module
│   ├── preprocessing.py       # Time-series scaler and sliding window pipeline
│   ├── model_training.py      # Keras LSTM builder and training loop
│   ├── prediction.py          # Next-day forecast inference engine
│   └── evaluation.py          # MAE, MSE, RMSE, and persistence baseline
│
├── utils/
│   ├── __init__.py
│   └── helpers.py             # Plotly chart creators & dark fintech theme
│
├── tests/
│   ├── test_preprocessing.py  # Unit tests for scaling & sequence generation
│   ├── test_prediction.py     # Unit tests for date logic & inference
│   └── test_evaluation.py     # Unit tests for error metric calculations
│
└── visualizations/            # Exported chart assets and loss curves
```

## 14. Installation Instructions
Clone the repository and install required dependencies in a virtual environment:

```bash
# Navigate to project directory
cd Tesla_Stock_Forecasting

# Create virtual environment
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

## 15. Execution Instructions
Launch the interactive Streamlit dashboard:

```bash
streamlit run app.py
```

Run automated unit tests:

```bash
pytest tests/ -v
```

## 16. Dashboard Screenshots & Pages
1. **Home Dashboard**: Company KPIs, latest closing price, model status, and overview chart.
2. **Stock Market Analysis**: Interactive candlestick/closing charts, volume subplots, date range sliders, and historical data tables.
3. **LSTM Model Training**: Interactive hyperparameters configuration, live training progress bar, and training vs validation loss curves.
4. **Stock Price Prediction**: Predicted next-trading-day closing price card, dollar delta, percentage movement, and market calendar calculations.
5. **Actual vs Predicted**: Dual-series interactive Plotly visualization comparing ground truth vs LSTM predictions across the test set.
6. **Model Performance**: Quantitative metric scoreboard (MAE, MSE, RMSE) and persistence baseline comparison.
7. **About Project**: Architectural documentation, system workflow, and future research avenues.

## 17. Results and Observations
- The 2-layer LSTM model tracks secular price trends and medium-term trajectories with high correlation.
- Test set RMSE remains within expected volatility thresholds for high-beta equities such as Tesla.
- Early stopping prevents overfitting to specific historical regime shifts.

## 18. Challenges and Solutions
- **Challenge**: Yahoo Finance API rate limits and connection throttling.  
  *Solution*: Robust error interception with automatic fallback to verified local CSV cache and user CSV upload modal.
- **Challenge**: Future lookahead bias in time-series scaling.  
  *Solution*: Strict chronological splitting where `MinMaxScaler` is fitted solely on the training partition.
- **Challenge**: Calendar anomalies (weekends & holidays).  
  *Solution*: Automated market day calculator that skips Saturdays and Sundays.

## 19. Future Enhancements
- Inclusion of Technical Indicators: MACD, RSI, Bollinger Bands, and Exponential Moving Averages (EMA).
- Multi-Variate Forecasting: Ingesting Open, High, Low, and Volume simultaneously.
- Sentiment Analysis: Ingesting financial news headlines and SEC 10-K filings using Gemini LLM.
- Comparative Deep Learning: Benchmarking against Gated Recurrent Units (GRU), Bi-directional LSTMs, and Temporal Transformers.

## 20. Limitations
- Pure historical price data cannot anticipate unexpected external black-swan shocks (earnings surprises, regulatory shifts, macro interest rate decisions).
- Deep learning predictions should be interpreted as scientific estimates, not financial or investment advice.

---
**License**: Apache-2.0
