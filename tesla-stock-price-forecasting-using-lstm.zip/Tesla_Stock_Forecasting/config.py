"""
Configuration settings for Tesla Stock Price Forecasting Using LSTM.
Defines project paths, model hyperparameters, dataset parameters, and visualization defaults.
"""

import os
from pathlib import Path

# Base Directories
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
VISUALIZATIONS_DIR = BASE_DIR / "visualizations"
SRC_DIR = BASE_DIR / "src"
UTILS_DIR = BASE_DIR / "utils"

# Ensure runtime directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
MODELS_DIR.mkdir(parents=True, exist_ok=True)
VISUALIZATIONS_DIR.mkdir(parents=True, exist_ok=True)

# Data Collection Parameters
STOCK_TICKER = "TSLA"
COMPANY_NAME = "Tesla, Inc."
DEFAULT_START_DATE = "2015-01-01"
DEFAULT_CSV_PATH = DATA_DIR / "tesla_stock.csv"

# Preprocessing Parameters
SEQUENCE_LENGTH = 60  # Lookback window: 60 trading days
TARGET_COLUMN = "Close"
FEATURE_COLUMNS = ["Date", "Open", "High", "Low", "Close", "Volume"]

# Chronological Data Splits
TRAIN_SPLIT_RATIO = 0.70
VAL_SPLIT_RATIO = 0.15
TEST_SPLIT_RATIO = 0.15

# LSTM Deep Learning Architecture
LSTM_UNITS_L1 = 50
LSTM_UNITS_L2 = 50
DENSE_UNITS = 25
OUTPUT_UNITS = 1

# Training Hyperparameters
DEFAULT_EPOCHS = 50
DEFAULT_BATCH_SIZE = 32
LEARNING_RATE = 0.001
LOSS_FUNCTION = "mean_squared_error"
OPTIMIZER = "adam"
RANDOM_SEED = 42

# Model Checkpoints & Artifacts
SAVED_MODEL_PATH = MODELS_DIR / "lstm_model.keras"
SCALER_PARAMS_PATH = MODELS_DIR / "scaler_params.json"
TRAINING_HISTORY_PATH = MODELS_DIR / "training_history.json"

# UI / Styling Theme Colors
THEME_NAVY_BG = "#0B132B"
THEME_CARD_BG = "#1C2541"
THEME_ACCENT_BLUE = "#3A86FF"
THEME_SUCCESS_GREEN = "#10B981"
THEME_DANGER_RED = "#EF4444"
THEME_TEXT_PRIMARY = "#F8FAFC"
THEME_TEXT_MUTED = "#94A3B8"
