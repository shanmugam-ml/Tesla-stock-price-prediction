"""
LSTM Deep Learning Model Architecture and Training Module.
Implements the stacked 2-layer LSTM neural network specified in Section 5
with Adam optimizer, early stopping, checkpointing, and .keras model serialization.
"""

import json
import os
import random
from pathlib import Path
from typing import Dict, Any, Optional, Tuple
import numpy as np

from config import (
    SEQUENCE_LENGTH,
    LSTM_UNITS_L1,
    LSTM_UNITS_L2,
    DENSE_UNITS,
    OUTPUT_UNITS,
    DEFAULT_EPOCHS,
    DEFAULT_BATCH_SIZE,
    LEARNING_RATE,
    LOSS_FUNCTION,
    RANDOM_SEED,
    SAVED_MODEL_PATH,
    TRAINING_HISTORY_PATH,
)


def set_reproducible_seeds(seed: int = RANDOM_SEED) -> None:
    """Sets random seeds across Python, NumPy, and TensorFlow."""
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import tensorflow as tf
        tf.random.set_seed(seed)
    except ImportError:
        pass


def build_lstm_model(
    input_shape: Tuple[int, int] = (SEQUENCE_LENGTH, 1),
    lstm_units_1: int = LSTM_UNITS_L1,
    lstm_units_2: int = LSTM_UNITS_L2,
    dense_units: int = DENSE_UNITS,
    output_units: int = OUTPUT_UNITS,
    learning_rate: float = LEARNING_RATE,
):
    """
    Constructs the specified Keras Sequential LSTM architecture:
    1. Input layer: (sequence_length, 1)
    2. LSTM Layer 1: 50 units, return_sequences=True
    3. LSTM Layer 2: 50 units, return_sequences=False
    4. Dense Layer: 25 neurons, ReLU activation
    5. Output Layer: 1 neuron, Linear activation
    """
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import LSTM, Dense, Input
    from tensorflow.keras.optimizers import Adam

    set_reproducible_seeds()

    model = Sequential([
        Input(shape=input_shape, name="input_sequence"),
        LSTM(lstm_units_1, return_sequences=True, name="lstm_layer_1"),
        LSTM(lstm_units_2, return_sequences=False, name="lstm_layer_2"),
        Dense(dense_units, activation="relu", name="dense_feature_extractor"),
        Dense(output_units, activation="linear", name="output_forecast"),
    ])

    optimizer = Adam(learning_rate=learning_rate)
    model.compile(optimizer=optimizer, loss=LOSS_FUNCTION, metrics=["mae"])
    return model


def train_lstm_model(
    X_train: np.ndarray,
    y_train: np.ndarray,
    X_val: np.ndarray,
    y_val: np.ndarray,
    epochs: int = DEFAULT_EPOCHS,
    batch_size: int = DEFAULT_BATCH_SIZE,
    model_save_path: Path = SAVED_MODEL_PATH,
    history_save_path: Path = TRAINING_HISTORY_PATH,
    progress_callback=None,
) -> Dict[str, Any]:
    """
    Trains the LSTM model with EarlyStopping and ModelCheckpoint.
    Saves the final trained model into .keras format.
    """
    import tensorflow as tf
    from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, Callback

    set_reproducible_seeds()
    model_save_path.parent.mkdir(parents=True, exist_ok=True)

    input_shape = (X_train.shape[1], X_train.shape[2])
    model = build_lstm_model(input_shape=input_shape)

    callbacks = [
        EarlyStopping(
            monitor="val_loss",
            patience=10,
            restore_best_weights=True,
            verbose=1,
            mode="min",
        ),
        ModelCheckpoint(
            filepath=str(model_save_path),
            monitor="val_loss",
            save_best_only=True,
            verbose=0,
            mode="min",
        ),
    ]

    # Custom callback to stream progress if provided (e.g. for Streamlit progress bar)
    if progress_callback:
        class StreamlitCallback(Callback):
            def on_epoch_end(self, epoch, logs=None):
                progress_callback(epoch + 1, epochs, logs)
        callbacks.append(StreamlitCallback())

    history = model.fit(
        X_train,
        y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        verbose=1,
        shuffle=False,  # Preserve sequential order in batches
    )

    # Save explicit final weights if checkpoint did not trigger
    model.save(str(model_save_path))

    # Persist training loss history for dashboard inspection
    history_dict = {
        "loss": [float(x) for x in history.history.get("loss", [])],
        "val_loss": [float(x) for x in history.history.get("val_loss", [])],
        "mae": [float(x) for x in history.history.get("mae", [])],
        "val_mae": [float(x) for x in history.history.get("val_mae", [])],
        "epochs_completed": len(history.history.get("loss", [])),
    }

    with open(history_save_path, "w") as f:
        json.dump(history_dict, f, indent=2)

    return {
        "model": model,
        "history": history_dict,
        "saved_path": str(model_save_path),
    }


def load_saved_model(model_path: Path = SAVED_MODEL_PATH):
    """Loads saved .keras LSTM model."""
    import tensorflow as tf
    if not model_path.exists():
        raise FileNotFoundError(f"Model file not found at {model_path}. Train the model first.")
    return tf.keras.models.load_model(str(model_path))
