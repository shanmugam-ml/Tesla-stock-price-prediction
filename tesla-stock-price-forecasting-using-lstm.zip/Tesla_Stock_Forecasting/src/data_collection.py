"""
Data Collection Module for Tesla (TSLA) Stock Market Analysis.
Handles historical data retrieval from Yahoo Finance (yfinance),
custom CSV validation, and file persistence.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple
import pandas as pd
import yfinance as yf

from config import DEFAULT_CSV_PATH, STOCK_TICKER, DEFAULT_START_DATE, FEATURE_COLUMNS


def fetch_tesla_stock_data(
    ticker: str = STOCK_TICKER,
    start_date: str = DEFAULT_START_DATE,
    end_date: Optional[str] = None,
    save_to_disk: bool = True,
    output_path: Path = DEFAULT_CSV_PATH,
) -> Tuple[pd.DataFrame, Optional[str]]:
    """
    Downloads historical stock data from Yahoo Finance via yfinance.

    Returns:
        Tuple[pd.DataFrame, Optional[str]]: (dataframe, error_message_if_any)
    """
    try:
        if end_date is None:
            end_date = datetime.now().strftime("%Y-%m-%d")

        # Download ticker history
        df = yf.download(ticker, start=start_date, end=end_date, progress=False)

        if df is None or df.empty:
            # Fallback check: try reading local cached CSV if internet or rate-limited
            if output_path.exists():
                cached_df = pd.read_csv(output_path)
                return cached_df, "Warning: Yahoo Finance returned empty data. Loaded cached historical dataset."
            return pd.DataFrame(), f"Error: No historical stock data retrieved for {ticker}."

        # Flatten multi-index columns if returned by yfinance
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        # Reset index to make Date a regular column
        df.reset_index(inplace=True)

        # Ensure Date column formatting
        if "Date" in df.columns:
            df["Date"] = pd.to_datetime(df["Date"]).dt.strftime("%Y-%m-%d")

        # Verify required columns exist
        missing_cols = [col for col in ["Date", "Open", "High", "Low", "Close", "Volume"] if col not in df.columns]
        if missing_cols:
            return pd.DataFrame(), f"Error: Downloaded data is missing required columns: {missing_cols}"

        # Clean numerical types
        numeric_cols = ["Open", "High", "Low", "Close", "Volume"]
        for col in numeric_cols:
            df[col] = pd.to_numeric(df[col], errors="coerce")

        df.dropna(subset=numeric_cols, inplace=True)
        df.sort_values(by="Date", ascending=True, inplace=True)
        df.reset_index(drop=True, inplace=True)

        if save_to_disk:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            df.to_csv(output_path, index=False)

        return df, None

    except Exception as e:
        # Fallback to local cache if offline or blocked
        if output_path.exists():
            try:
                cached_df = pd.read_csv(output_path)
                return cached_df, f"Network notice ({str(e)}). Loaded verified local historical dataset."
            except Exception:
                pass
        return pd.DataFrame(), f"Failed to retrieve stock data: {str(e)}"


def load_custom_csv(uploaded_file_or_path) -> Tuple[pd.DataFrame, Optional[str]]:
    """
    Loads and validates a user-uploaded CSV dataset.
    Validates presence of Date, Open, High, Low, Close, Volume.
    """
    try:
        df = pd.read_csv(uploaded_file_or_path)

        if df.empty:
            return pd.DataFrame(), "Uploaded CSV is empty."

        # Case-insensitive column matching
        col_mapping = {col.strip().title(): col for col in df.columns}
        required_cols = ["Date", "Open", "High", "Low", "Close", "Volume"]

        for req in required_cols:
            if req not in col_mapping and req.lower() not in [c.lower() for c in df.columns]:
                return pd.DataFrame(), f"Validation Error: Missing required column '{req}' in CSV."

        # Standardize column names
        rename_dict = {}
        for col in df.columns:
            for req in required_cols:
                if col.strip().lower() == req.lower():
                    rename_dict[col] = req
        df.rename(columns=rename_dict, inplace=True)

        # Convert Date
        df["Date"] = pd.to_datetime(df["Date"], errors="coerce").dt.strftime("%Y-%m-%d")
        df.dropna(subset=["Date"], inplace=True)

        # Validate numerical types
        for col in ["Open", "High", "Low", "Close", "Volume"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")

        df.dropna(subset=["Open", "High", "Low", "Close", "Volume"], inplace=True)
        df.sort_values("Date", ascending=True, inplace=True)
        df.drop_duplicates(subset=["Date"], keep="last", inplace=True)
        df.reset_index(drop=True, inplace=True)

        if len(df) < 100:
            return pd.DataFrame(), "Validation Error: Dataset must contain at least 100 historical trading days for time-series modeling."

        return df, None

    except Exception as e:
        return pd.DataFrame(), f"Failed to parse uploaded CSV: {str(e)}"


def get_latest_market_metadata(df: pd.DataFrame) -> dict:
    """
    Extracts summary statistics for dashboard KPI cards.
    """
    if df.empty or "Close" not in df.columns or "Date" not in df.columns:
        return {
            "total_records": 0,
            "latest_date": "N/A",
            "latest_close": 0.0,
            "min_close": 0.0,
            "max_close": 0.0,
            "all_time_change_pct": 0.0,
        }

    latest_close = float(df["Close"].iloc[-1])
    first_close = float(df["Close"].iloc[0])
    pct_change = ((latest_close - first_close) / first_close) * 100

    return {
        "total_records": len(df),
        "start_date": str(df["Date"].iloc[0]),
        "latest_date": str(df["Date"].iloc[-1]),
        "latest_close": latest_close,
        "min_close": float(df["Close"].min()),
        "max_close": float(df["Close"].max()),
        "all_time_change_pct": pct_change,
        "avg_volume": float(df["Volume"].mean()),
    }
