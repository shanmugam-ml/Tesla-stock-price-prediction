"""
Data Preprocessing Module for Tesla Stock Forecasting.
Implements chronological train-validation-test split, MinMaxScaler fitting
strictly on training set (zero data leakage), sequential sliding window generation,
and inverse scaling back to USD.
"""

from typing import Tuple, Dict, Any, Optional
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

from config import (
    SEQUENCE_LENGTH,
    TARGET_COLUMN,
    TRAIN_SPLIT_RATIO,
    VAL_SPLIT_RATIO,
    TEST_SPLIT_RATIO,
)


class StockDataPreprocessor:
    """
    Manages data sanitization, scaling, and sequential windowing
    for time-series deep learning without future data leakage.
    """

    def __init__(self, sequence_length: int = SEQUENCE_LENGTH):
        self.sequence_length = sequence_length
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.is_fitted = False
        self.min_val: Optional[float] = None
        self.max_val: Optional[float] = None

    def clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Cleans raw financial dataframe:
        - Drops duplicates
        - Converts Date to datetime and formats as YYYY-MM-DD
        - Sorts chronologically
        - Handles NaN/infinite values
        """
        df_clean = df.copy()

        # Deduplicate
        if "Date" in df_clean.columns:
            df_clean["Date"] = pd.to_datetime(df_clean["Date"], errors="coerce")
            df_clean.dropna(subset=["Date"], inplace=True)
            df_clean.sort_values(by="Date", ascending=True, inplace=True)
            df_clean.drop_duplicates(subset=["Date"], keep="last", inplace=True)
            df_clean["Date"] = df_clean["Date"].dt.strftime("%Y-%m-%d")

        # Validate numeric columns
        for col in ["Open", "High", "Low", "Close", "Volume"]:
            if col in df_clean.columns:
                df_clean[col] = pd.to_numeric(df_clean[col], errors="coerce")

        df_clean.dropna(subset=[TARGET_COLUMN], inplace=True)
        df_clean.reset_index(drop=True, inplace=True)
        return df_clean

    def fit_transform_training_data(self, train_series: np.ndarray) -> np.ndarray:
        """
        Fits scaler strictly on training target values and scales them to [0, 1].
        """
        train_reshaped = train_series.reshape(-1, 1)
        scaled = self.scaler.fit_transform(train_reshaped)
        self.is_fitted = True
        self.min_val = float(self.scaler.data_min_[0])
        self.max_val = float(self.scaler.data_max_[0])
        return scaled

    def transform(self, series: np.ndarray) -> np.ndarray:
        """
        Transforms evaluation or unseen series using already-fitted scaler.
        """
        if not self.is_fitted:
            raise ValueError("Preprocessor scaler must be fitted on training data before transforming.")
        return self.scaler.transform(series.reshape(-1, 1))

    def inverse_transform(self, scaled_series: np.ndarray) -> np.ndarray:
        """
        Reverts normalized [0, 1] values back to original USD price scale.
        """
        if not self.is_fitted:
            raise ValueError("Scaler is not fitted yet.")
        reshaped = np.array(scaled_series).reshape(-1, 1)
        return self.scaler.inverse_transform(reshaped).flatten()

    def create_sequences(
        self, data: np.ndarray, dates: Optional[np.ndarray] = None
    ) -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
        """
        Creates (X, y) sliding window sequences.
        X shape: (samples, sequence_length, 1)
        y shape: (samples,)
        """
        X, y, target_dates = [], [], []
        data_flat = data.flatten()

        for i in range(self.sequence_length, len(data_flat)):
            X.append(data_flat[i - self.sequence_length : i])
            y.append(data_flat[i])
            if dates is not None and len(dates) > i:
                target_dates.append(dates[i])

        X_arr = np.array(X)
        y_arr = np.array(y)
        X_reshaped = np.reshape(X_arr, (X_arr.shape[0], X_arr.shape[1], 1))

        dates_arr = np.array(target_dates) if dates is not None else None
        return X_reshaped, y_arr, dates_arr

    def prepare_full_pipeline(
        self, df: pd.DataFrame
    ) -> Dict[str, Any]:
        """
        Executes full chronological split and sequence generation:
        - 70% Train, 15% Validation, 15% Test
        - Scaler fitted exclusively on Train
        - Validation and Test transformed using Train scaler
        - Preserves chronological dates for test predictions
        """
        clean_df = self.clean_data(df)
        total_rows = len(clean_df)

        if total_rows < self.sequence_length + 20:
            raise ValueError(
                f"Insufficient data: Received {total_rows} rows, but requires at least "
                f"{self.sequence_length + 20} for train/val/test sequencing."
            )

        closes = clean_df[TARGET_COLUMN].values.astype(np.float32)
        dates = clean_df["Date"].values

        # Chronological index splits
        train_end = int(total_rows * TRAIN_SPLIT_RATIO)
        val_end = train_end + int(total_rows * VAL_SPLIT_RATIO)

        # Slice raw sets
        train_raw = closes[:train_end]
        val_raw_with_context = closes[train_end - self.sequence_length : val_end]
        test_raw_with_context = closes[val_end - self.sequence_length :]

        val_dates = dates[train_end:val_end]
        test_dates = dates[val_end:]

        # Fit scaler ONLY on train
        train_scaled = self.fit_transform_training_data(train_raw)
        val_scaled = self.transform(val_raw_with_context)
        test_scaled = self.transform(test_raw_with_context)

        # Build sliding windows
        X_train, y_train, _ = self.create_sequences(train_scaled)
        X_val, y_val, _ = self.create_sequences(val_scaled)
        X_test, y_test, matched_test_dates = self.create_sequences(test_scaled, dates=test_dates)

        # Extract actual test prices in original USD
        actual_test_usd = self.inverse_transform(y_test)

        return {
            "preprocessor": self,
            "clean_df": clean_df,
            "train": {"X": X_train, "y": y_train, "count": len(X_train)},
            "val": {"X": X_val, "y": y_val, "count": len(X_val)},
            "test": {
                "X": X_test,
                "y": y_test,
                "actual_usd": actual_test_usd,
                "dates": matched_test_dates,
                "count": len(X_test),
            },
            "scaler_meta": {
                "min": self.min_val,
                "max": self.max_val,
            },
        }
