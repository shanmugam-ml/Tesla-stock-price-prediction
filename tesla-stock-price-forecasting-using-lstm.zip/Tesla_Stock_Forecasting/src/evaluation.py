"""
Model Evaluation Module for Tesla Stock Forecasting.
Calculates Mean Absolute Error (MAE), Mean Squared Error (MSE),
Root Mean Squared Error (RMSE) on inverse-transformed USD prices,
and benchmarks against a persistence baseline (Tomorrow's Close = Today's Close).
"""

from typing import Dict, Any, Tuple
import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error


def calculate_metrics(y_true_usd: np.ndarray, y_pred_usd: np.ndarray) -> Dict[str, float]:
    """
    Computes MAE, MSE, RMSE on original USD stock price scale.
    """
    mae = float(mean_absolute_error(y_true_usd, y_pred_usd))
    mse = float(mean_squared_error(y_true_usd, y_pred_usd))
    rmse = float(np.sqrt(mse))
    mape = float(np.mean(np.abs((y_true_usd - y_pred_usd) / y_true_usd)) * 100)

    return {
        "mae": round(mae, 4),
        "mse": round(mse, 4),
        "rmse": round(rmse, 4),
        "mape": round(mape, 2),
    }


def calculate_persistence_baseline(
    actual_test_usd: np.ndarray,
) -> Tuple[np.ndarray, Dict[str, float]]:
    """
    Implements standard financial naive persistence baseline:
    Predicted Price (t) = Actual Price (t-1).

    Returns:
        baseline_predictions: Array of persistence forecasts
        metrics: Dict containing baseline MAE, MSE, RMSE
    """
    if len(actual_test_usd) < 2:
        raise ValueError("Need at least 2 test samples to calculate baseline.")

    # Baseline predicts price at t equals price at t-1
    # For alignment with actuals from index 1 onward:
    baseline_pred = actual_test_usd[:-1]
    baseline_true = actual_test_usd[1:]

    metrics = calculate_metrics(baseline_true, baseline_pred)
    return baseline_pred, metrics


def evaluate_lstm_vs_baseline(
    actual_test_usd: np.ndarray,
    predicted_test_usd: np.ndarray,
) -> Dict[str, Any]:
    """
    Conducts comparative evaluation of LSTM vs Naive Baseline on identical test set.
    """
    lstm_metrics = calculate_metrics(actual_test_usd, predicted_test_usd)

    # Calculate baseline on same test segment
    _, baseline_metrics = calculate_persistence_baseline(actual_test_usd)

    # Relative difference percentages
    mae_improvement_pct = ((baseline_metrics["mae"] - lstm_metrics["mae"]) / baseline_metrics["mae"]) * 100
    rmse_improvement_pct = ((baseline_metrics["rmse"] - lstm_metrics["rmse"]) / baseline_metrics["rmse"]) * 100

    return {
        "lstm": lstm_metrics,
        "baseline": baseline_metrics,
        "comparison": {
            "mae_delta": round(baseline_metrics["mae"] - lstm_metrics["mae"], 4),
            "rmse_delta": round(baseline_metrics["rmse"] - lstm_metrics["rmse"], 4),
            "mae_improvement_pct": round(mae_improvement_pct, 2),
            "rmse_improvement_pct": round(rmse_improvement_pct, 2),
        },
    }
