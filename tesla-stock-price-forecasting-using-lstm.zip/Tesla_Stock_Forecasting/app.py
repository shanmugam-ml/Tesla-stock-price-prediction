"""
Streamlit Web Application: TESLA STOCK PRICE FORECASTING USING LSTM
A deep learning financial analytics dashboard implementing end-to-end data collection,
preprocessing, 2-layer LSTM modeling, next-trading-day forecasting, and performance evaluation.
"""

import os
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import streamlit as st

# Add current directory and src to sys.path
BASE_DIR = Path(__file__).resolve().parent
SRC_DIR = BASE_DIR / "src"
UTILS_DIR = BASE_DIR / "utils"
sys.path.extend([str(BASE_DIR), str(SRC_DIR), str(UTILS_DIR)])

from config import (
    STOCK_TICKER,
    COMPANY_NAME,
    DEFAULT_CSV_PATH,
    SAVED_MODEL_PATH,
    SEQUENCE_LENGTH,
    DEFAULT_EPOCHS,
    DEFAULT_BATCH_SIZE,
    THEME_NAVY_BG,
    THEME_CARD_BG,
    THEME_ACCENT_BLUE,
)
from data_collection import fetch_tesla_stock_data, load_custom_csv, get_latest_market_metadata
from preprocessing import StockDataPreprocessor
from model_training import build_lstm_model, train_lstm_model, load_saved_model
from prediction import predict_next_trading_day, predict_test_dataset
from evaluation import evaluate_lstm_vs_baseline
from helpers import (
    create_historical_price_chart,
    create_actual_vs_predicted_chart,
    create_training_loss_chart,
    create_metrics_comparison_chart,
    create_daily_returns_histogram,
)

# Page configuration
st.set_page_config(
    page_title="Tesla Stock Forecasting | LSTM Deep Learning",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom CSS for dark fintech terminal styling
st.markdown(
    """
    <style>
    .main {
        background-color: #0B132B;
        color: #F8FAFC;
    }
    .stApp {
        background-color: #0B132B;
    }
    div[data-testid="stSidebar"] {
        background-color: #1C2541;
        border-right: 1px solid #2A3859;
    }
    .metric-card {
        background-color: #1C2541;
        border: 1px solid #2A3859;
        border-radius: 10px;
        padding: 18px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
    }
    .metric-value {
        font-family: 'JetBrains Mono', monospace;
        font-size: 1.8rem;
        font-weight: 700;
        color: #3A86FF;
    }
    .metric-label {
        font-size: 0.85rem;
        color: #94A3B8;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .prediction-hero {
        background: linear-gradient(135deg, #1C2541 0%, #0F172A 100%);
        border: 1px solid #3A86FF;
        border-radius: 12px;
        padding: 24px;
        text-align: center;
        margin: 20px 0;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_data(ttl=3600)
def load_stock_data(source_type: str = "auto", uploaded_file=None):
    """Cached loader for historical TSLA data."""
    if source_type == "upload" and uploaded_file is not None:
        return load_custom_csv(uploaded_file)
    else:
        return fetch_tesla_stock_data(save_to_disk=True)


# Sidebar Navigation
st.sidebar.markdown(
    """
    <div style='text-align: center; padding: 10px 0;'>
        <h2 style='color: #3A86FF; margin: 0;'>TSLA FORECAST</h2>
        <p style='color: #94A3B8; font-size: 0.85rem;'>LSTM Neural Network Engine</p>
    </div>
    """,
    unsafe_allow_html=True,
)

pages = [
    "1. Home Dashboard",
    "2. Stock Market Analysis",
    "3. LSTM Model Training",
    "4. Stock Price Prediction",
    "5. Actual vs Predicted",
    "6. Model Performance",
    "7. About Project",
]

selected_page = st.sidebar.radio("Navigation", pages)

st.sidebar.markdown("---")
st.sidebar.markdown(
    """
    **Dataset Source**: Yahoo Finance (yfinance)  
    **Target Ticker**: TSLA (Tesla Inc.)  
    **Lookback Window**: 60 Trading Days  
    **Deep Learning**: TensorFlow / Keras LSTM
    """
)

# Global dataset loading
data_source = st.sidebar.selectbox("Data Input Mode", ["Auto-fetch (Yahoo Finance)", "Upload Custom CSV"])
uploaded_csv = None
if data_source == "Upload Custom CSV":
    uploaded_csv = st.sidebar.file_uploader("Upload TSLA Historical CSV", type=["csv"])

with st.spinner("Loading Tesla historical market data..."):
    df, err = load_stock_data("upload" if data_source == "Upload Custom CSV" else "auto", uploaded_csv)

if err and df.empty:
    st.error(f"Failed to load dataset: {err}")
    st.stop()
elif err:
    st.info(err)

meta = get_latest_market_metadata(df)

# ==========================================
# PAGE 1: HOME DASHBOARD
# ==========================================
if selected_page == "1. Home Dashboard":
    st.title("Tesla Stock Price Forecasting Using LSTM")
    st.markdown(
        """
        An enterprise-grade deep learning financial application that analyzes historical **Tesla Inc. (TSLA)**
        trading sessions and forecasts the **next trading day's closing price** using a multi-layer
        Long Short-Term Memory (LSTM) recurrent neural network.
        """
    )

    # KPI Top Row
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-label">Stock Ticker</div>
                <div class="metric-value">{STOCK_TICKER}</div>
                <small style="color: #94A3B8;">{COMPANY_NAME}</small>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col2:
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-label">Latest Close Price</div>
                <div class="metric-value">${meta['latest_close']:.2f}</div>
                <small style="color: #94A3B8;">As of {meta['latest_date']}</small>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col3:
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-label">Historical Records</div>
                <div class="metric-value">{meta['total_records']:,}</div>
                <small style="color: #94A3B8;">Trading Sessions (2015-Now)</small>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with col4:
        model_exists = SAVED_MODEL_PATH.exists()
        status_text = "READY / TRAINED" if model_exists else "UNTRAINED"
        status_color = "#10B981" if model_exists else "#EF4444"
        st.markdown(
            f"""
            <div class="metric-card">
                <div class="metric-label">LSTM Model Status</div>
                <div class="metric-value" style="color: {status_color}; font-size: 1.3rem;">{status_text}</div>
                <small style="color: #94A3B8;">{'models/lstm_model.keras' if model_exists else 'Awaiting Training'}</small>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.markdown("### Why LSTM For Stock Market Forecasting?")
    st.markdown(
        """
        Stock market prices constitute non-linear, non-stationary sequential time-series data. Standard feed-forward
        neural networks or traditional regression methods treat each data observation independently, failing to capture
        temporal dependencies and momentum patterns.

        **Long Short-Term Memory (LSTM)** networks solve this fundamental constraint via specialized memory cells
        governed by three gates:
        - **Forget Gate**: Discards irrelevant historical noise.
        - **Input Gate**: Selects valuable incoming price information.
        - **Output Gate**: Determines the sequential memory passed into the subsequent forecast.

        This architecture processes the previous **60 trading days** (approximately 3 calendar months of market memory)
        to model non-linear price trajectories.
        """
    )

    # Overview chart preview
    fig_hist = create_historical_price_chart(df)
    st.plotly_chart(fig_hist, use_container_width=True)

# ==========================================
# PAGE 2: STOCK MARKET ANALYSIS
# ==========================================
elif selected_page == "2. Stock Market Analysis":
    st.title("Tesla (TSLA) Stock Market Analysis")
    st.markdown("Comprehensive exploratory analysis of historical daily OHLC prices and trading volume.")

    # Date range filter
    min_date = pd.to_datetime(df["Date"].min()).date()
    max_date = pd.to_datetime(df["Date"].max()).date()

    col_start, col_end = st.columns(2)
    with col_start:
        start_filter = st.date_input("Start Date", min_date, min_value=min_date, max_value=max_date)
    with col_end:
        end_filter = st.date_input("End Date", max_date, min_value=min_date, max_value=max_date)

    filtered_df = df[
        (pd.to_datetime(df["Date"]).dt.date >= start_filter)
        & (pd.to_datetime(df["Date"]).dt.date <= end_filter)
    ].copy()

    st.markdown(f"**Showing {len(filtered_df):,} trading sessions** from `{start_filter}` to `{end_filter}`.")

    # Interactive charts
    fig_price = create_historical_price_chart(filtered_df)
    st.plotly_chart(fig_price, use_container_width=True)

    col_chart1, col_chart2 = st.columns(2)
    with col_chart1:
        fig_ret = create_daily_returns_histogram(filtered_df)
        st.plotly_chart(fig_ret, use_container_width=True)
    with col_chart2:
        st.markdown("### Key Market Metrics")
        st.write(
            {
                "Period High (USD)": f"${filtered_df['High'].max():.2f}",
                "Period Low (USD)": f"${filtered_df['Low'].min():.2f}",
                "Period Average Close": f"${filtered_df['Close'].mean():.2f}",
                "Average Daily Volume": f"{filtered_df['Volume'].mean():,.0f} shares",
                "Max Single-Day Volume": f"{filtered_df['Volume'].max():,.0f} shares",
            }
        )

    # Historical Data Table
    st.markdown("### Historical Stock Data Table")
    st.dataframe(
        filtered_df.sort_values(by="Date", ascending=False),
        use_container_width=True,
        height=350,
    )

# ==========================================
# PAGE 3: LSTM MODEL TRAINING
# ==========================================
elif selected_page == "3. LSTM Model Training":
    st.title("Train LSTM Deep Learning Model")
    st.markdown(
        """
        Configure model hyperparameters and train the 2-layer stacked LSTM network.
        Data is chronologically partitioned into **70% Training**, **15% Validation**, and **15% Testing**.
        """
    )

    col_hyp1, col_hyp2, col_hyp3 = st.columns(3)
    with col_hyp1:
        epochs = st.slider("Training Epochs", min_value=5, max_value=100, value=DEFAULT_EPOCHS, step=5)
    with col_hyp2:
        batch_size = st.selectbox("Batch Size", [16, 32, 64, 128], index=1)
    with col_hyp3:
        seq_length = st.number_input("Sequence Length (Lookback Days)", min_value=20, max_value=120, value=SEQUENCE_LENGTH)

    st.markdown("#### Model Architecture Specification:")
    st.code(
        f"""
Sequential Model Architecture:
- Input Layer:      Shape ({seq_length}, 1)
- LSTM Layer 1:     50 units, return_sequences=True, Dropout=0.0
- LSTM Layer 2:     50 units, return_sequences=False
- Dense Layer:      25 neurons, Activation='relu'
- Output Layer:     1 neuron, Activation='linear'
- Loss Function:    Mean Squared Error (MSE)
- Optimizer:        Adam (lr=0.001)
        """,
        language="text",
    )

    if st.button("🚀 Train LSTM Model Now", use_container_width=True, type="primary"):
        with st.status("Preprocessing data and training LSTM neural network...", expanded=True) as status:
            try:
                preprocessor = StockDataPreprocessor(sequence_length=seq_length)
                st.write("Splitting dataset chronologically without data leakage...")
                pipeline_data = preprocessor.prepare_full_pipeline(df)

                X_train = pipeline_data["train"]["X"]
                y_train = pipeline_data["train"]["y"]
                X_val = pipeline_data["val"]["X"]
                y_val = pipeline_data["val"]["y"]

                st.write(f"Training Samples: {len(X_train)} | Validation Samples: {len(X_val)}")
                progress_bar = st.progress(0)

                def update_progress(curr, total, logs):
                    pct = int((curr / total) * 100)
                    progress_bar.progress(pct)

                st.write("Fitting LSTM weights across epochs...")
                train_result = train_lstm_model(
                    X_train,
                    y_train,
                    X_val,
                    y_val,
                    epochs=epochs,
                    batch_size=batch_size,
                    progress_callback=update_progress,
                )

                status.update(label="Training successfully completed! Model saved to models/lstm_model.keras", state="complete")
                st.success("Model successfully trained and persisted!")

                # Plot learning curves
                fig_loss = create_training_loss_chart(train_result["history"])
                st.plotly_chart(fig_loss, use_container_width=True)

            except Exception as e:
                status.update(label=f"Training Failed: {str(e)}", state="error")
                st.error(f"Error during training: {str(e)}")

# ==========================================
# PAGE 4: STOCK PRICE PREDICTION
# ==========================================
elif selected_page == "4. Stock Price Prediction":
    st.title("Next Trading Day Stock Price Forecast")
    st.markdown("Inference engine predicting Tesla's next-trading-day closing price from the latest 60 sessions.")

    if not SAVED_MODEL_PATH.exists():
        st.warning("⚠️ No trained LSTM model found. Please navigate to '3. LSTM Model Training' and train the model first.")
    else:
        try:
            model = load_saved_model(SAVED_MODEL_PATH)
            preprocessor = StockDataPreprocessor(sequence_length=SEQUENCE_LENGTH)
            # Reconstruct training scale from data
            _ = preprocessor.prepare_full_pipeline(df)

            forecast = predict_next_trading_day(model, preprocessor, df)

            st.markdown(
                f"""
                <div class="prediction-hero">
                    <h3 style="color: #94A3B8; margin-bottom: 5px;">FORECAST TARGET: {forecast['next_trading_day']}</h3>
                    <div style="font-size: 3rem; font-weight: 800; color: {'#10B981' if forecast['price_difference'] >= 0 else '#EF4444'};">
                        ${forecast['predicted_next_close']:.2f} USD
                    </div>
                    <div style="font-size: 1.2rem; color: #F8FAFC; margin-top: 10px;">
                        Expected Delta: <b>{'+' if forecast['price_difference'] >= 0 else ''}{forecast['price_difference']:.2f} USD</b>
                        ({'+' if forecast['percent_change'] >= 0 else ''}{forecast['percent_change']:.2f}%)
                    </div>
                </div>
                """,
                unsafe_allow_html=True,
            )

            col_p1, col_p2, col_p3 = st.columns(3)
            with col_p1:
                st.metric("Latest Market Close", f"${forecast['last_closing_price']:.2f}", f"As of {forecast['last_market_date']}")
            with col_p2:
                st.metric("Forecasted Next Close", f"${forecast['predicted_next_close']:.2f}", f"{forecast['percent_change']:+.2f}%")
            with col_p3:
                st.metric("Signal Direction", forecast["direction"], f"Based on {forecast['lookback_period_days']} Lookback Days")

            st.info(forecast["disclaimer"])

        except Exception as e:
            st.error(f"Prediction inference error: {str(e)}")

# ==========================================
# PAGE 5: ACTUAL VS PREDICTED
# ==========================================
elif selected_page == "5. Actual vs Predicted":
    st.title("Actual vs Predicted Price Comparison")
    st.markdown("Chronological validation of LSTM predictions against real market closing prices across the test set.")

    if not SAVED_MODEL_PATH.exists():
        st.warning("⚠️ No trained model found. Please train the model on Page 3 first.")
    else:
        try:
            model = load_saved_model(SAVED_MODEL_PATH)
            preprocessor = StockDataPreprocessor(sequence_length=SEQUENCE_LENGTH)
            pipeline_data = preprocessor.prepare_full_pipeline(df)

            X_test = pipeline_data["test"]["X"]
            actual_usd = pipeline_data["test"]["actual_usd"]
            dates = pipeline_data["test"]["dates"]

            predicted_usd = predict_test_dataset(model, preprocessor, X_test)

            fig_comp = create_actual_vs_predicted_chart(list(dates), actual_usd, predicted_usd)
            st.plotly_chart(fig_comp, use_container_width=True)

            # Inspection table
            comp_df = pd.DataFrame({
                "Date": dates,
                "Actual Close (USD)": [round(x, 2) for x in actual_usd],
                "Predicted Close (USD)": [round(x, 2) for x in predicted_usd],
                "Error (USD)": [round(p - a, 2) for a, p in zip(actual_usd, predicted_usd)],
                "Absolute % Error": [round(abs(p - a) / a * 100, 2) for a, p in zip(actual_usd, predicted_usd)],
            })

            st.markdown("### Test Set Prediction Inspector")
            st.dataframe(comp_df.sort_values(by="Date", ascending=False), use_container_width=True, height=350)

        except Exception as e:
            st.error(f"Evaluation error: {str(e)}")

# ==========================================
# PAGE 6: MODEL PERFORMANCE
# ==========================================
elif selected_page == "6. Model Performance":
    st.title("Model Performance & Quantitative Evaluation")
    st.markdown("Evaluation of model accuracy using MAE, MSE, and RMSE against a Naive Persistence Baseline.")

    if not SAVED_MODEL_PATH.exists():
        st.warning("⚠️ Train the model first on Page 3 to view performance metrics.")
    else:
        try:
            model = load_saved_model(SAVED_MODEL_PATH)
            preprocessor = StockDataPreprocessor(sequence_length=SEQUENCE_LENGTH)
            pipeline_data = preprocessor.prepare_full_pipeline(df)

            X_test = pipeline_data["test"]["X"]
            actual_usd = pipeline_data["test"]["actual_usd"]
            predicted_usd = predict_test_dataset(model, preprocessor, X_test)

            eval_res = evaluate_lstm_vs_baseline(actual_usd, predicted_usd)
            lstm_m = eval_res["lstm"]
            base_m = eval_res["baseline"]

            col_m1, col_m2, col_m3 = st.columns(3)
            with col_m1:
                st.metric("LSTM MAE", f"${lstm_m['mae']:.2f}", f"Baseline: ${base_m['mae']:.2f}", delta_color="inverse")
            with col_m2:
                st.metric("LSTM MSE", f"{lstm_m['mse']:.2f}", f"Baseline: {base_m['mse']:.2f}", delta_color="inverse")
            with col_m3:
                st.metric("LSTM RMSE", f"${lstm_m['rmse']:.2f}", f"Baseline: ${base_m['rmse']:.2f}", delta_color="inverse")

            fig_bar = create_metrics_comparison_chart(lstm_m, base_m)
            st.plotly_chart(fig_bar, use_container_width=True)

            st.markdown("### Metric Definitions")
            st.markdown(
                """
                - **Mean Absolute Error (MAE)**: $\\frac{1}{n} \\sum |y_i - \\hat{y}_i|$. Represents the average absolute dollar discrepancy between predicted and actual closing prices.
                - **Mean Squared Error (MSE)**: $\\frac{1}{n} \\sum (y_i - \\hat{y}_i)^2$. Heavily penalizes large variance outliers in stock forecasts.
                - **Root Mean Squared Error (RMSE)**: $\\sqrt{\\text{MSE}}$. Restores the penalty metric to original USD units for intuitive volatility interpretation.
                - **Persistence Baseline**: The gold standard benchmark in financial econometrics ($y_{t+1} = y_t$). Any forecasting model must outperform this naive benchmark to prove non-random sequential learning.
                """
            )

        except Exception as e:
            st.error(f"Error computing performance metrics: {str(e)}")

# ==========================================
# PAGE 7: ABOUT PROJECT
# ==========================================
elif selected_page == "7. About Project":
    st.title("About: Tesla Stock Price Forecasting Using LSTM")
    st.markdown(
        """
        ### Executive Abstract
        Stock price forecasting remains one of the most intellectually challenging tasks in financial econometrics due to
        market volatility, macroeconomic shifts, and non-linear temporal dependencies. This project demonstrates an end-to-end
        deep learning implementation using a **two-layer Long Short-Term Memory (LSTM) recurrent neural network** trained on
        real historical **Tesla Inc. (TSLA)** data collected via Yahoo Finance.

        ---

        ### 1. Problem Statement
        Predicting the next trading day's closing price requires analyzing sequential price momentum without succumbing to
        data leakage, overfitting, or spurious correlation. Traditional statistical methods such as ARIMA assume linearity,
        which frequently breaks down during market turbulence.

        ### 2. Project Objectives
        - Collect authentic daily historical stock data for TSLA.
        - Preprocess raw financial records, handling missing values, anomalies, and duplicates.
        - Formulate chronological 60-day sliding window sequences.
        - Fit scaling transformations strictly on training subsets (preventing lookahead bias).
        - Train a stacked 2-layer LSTM deep learning architecture.
        - Perform rigorous out-of-sample quantitative evaluation against naive persistence baselines.
        - Deploy an interactive financial analytics terminal interface.

        ### 3. Technology Stack
        - **Language**: Python 3.10
        - **Deep Learning**: TensorFlow 2.x, Keras
        - **Data Processing**: Pandas, NumPy, Scikit-learn
        - **Market Data**: Yahoo Finance (`yfinance`)
        - **Dashboard**: Streamlit, Plotly

        ### 4. Limitations & Real-world Considerations
        - Financial markets are influenced by exogenous events (earnings reports, Elon Musk tweets, regulatory filings, geopolitical interest rate shifts) not captured by pure price history.
        - LSTM models act as momentum and trajectory learners, not crystal balls.
        - Past performance does not guarantee future financial returns.

        ### 5. Future Enhancements
        - Integration of technical indicators (RSI, MACD, Bollinger Bands).
        - Multi-feature input sequences incorporating Trading Volume, High, and Low.
        - Financial news sentiment analysis via Gemini LLM integration.
        - Multi-step forward forecasting (5-day and 30-day horizons).
        """
    )
