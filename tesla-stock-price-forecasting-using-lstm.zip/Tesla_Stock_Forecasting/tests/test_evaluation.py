"""
Unit tests for model evaluation and baseline calculation.
"""

import numpy as np
import pytest

from evaluation import calculate_metrics, calculate_persistence_baseline, evaluate_lstm_vs_baseline


def test_calculate_metrics_accuracy():
    y_true = np.array([100.0, 200.0, 300.0])
    y_pred = np.array([110.0, 190.0, 300.0])

    metrics = calculate_metrics(y_true, y_pred)

    # MAE = (|10| + |-10| + 0) / 3 = 20 / 3 = 6.6667
    assert abs(metrics["mae"] - 6.6667) < 1e-3

    # MSE = (100 + 100 + 0) / 3 = 200 / 3 = 66.6667
    assert abs(metrics["mse"] - 66.6667) < 1e-3

    # RMSE = sqrt(66.6667) = 8.165
    assert abs(metrics["rmse"] - 8.165) < 1e-2


def test_persistence_baseline_computation():
    actual_series = np.array([100.0, 105.0, 103.0, 110.0])
    baseline_pred, metrics = calculate_persistence_baseline(actual_series)

    # Predictions for t=1..3 are [100.0, 105.0, 103.0]
    np.testing.assert_array_equal(baseline_pred, [100.0, 105.0, 103.0])

    # True values are [105.0, 103.0, 110.0]
    # Errors: |105-100|=5, |103-105|=2, |110-103|=7 -> MAE = (5+2+7)/3 = 4.6667
    assert abs(metrics["mae"] - 4.6667) < 1e-3
