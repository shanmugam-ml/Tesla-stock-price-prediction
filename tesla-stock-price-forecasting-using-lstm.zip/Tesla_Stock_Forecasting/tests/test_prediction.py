"""
Unit tests for next trading day prediction logic and date computation.
"""

from prediction import get_next_trading_day


def test_get_next_trading_day_weekday():
    # Wednesday -> Thursday
    assert get_next_trading_day("2023-03-15") == "2023-03-16"


def test_get_next_trading_day_weekend_skip():
    # Friday -> Monday
    assert get_next_trading_day("2023-03-17") == "2023-03-20"
    # Saturday -> Monday
    assert get_next_trading_day("2023-03-18") == "2023-03-20"
