"""
Unit tests for data preprocessing and time-series sequencing.
"""

import numpy as np
import pandas as pd
import pytest

from preprocessing import StockDataPreprocessor


def test_clean_data_handles_duplicates_and_sorting():
    raw_data = {
        "Date": ["2023-01-05", "2023-01-02", "2023-01-02", "2023-01-03"],
        "Open": [105.0, 100.0, 100.0, 102.0],
        "High": [108.0, 102.0, 102.0, 104.0],
        "Low": [104.0, 99.0, 99.0, 101.0],
        "Close": [107.0, 101.0, 101.0, 103.0],
        "Volume": [1000, 1200, 1200, 1100],
    }
    df = pd.DataFrame(raw_data)
    preprocessor = StockDataPreprocessor(sequence_length=2)
    cleaned = preprocessor.clean_data(df)

    assert len(cleaned) == 3
    assert list(cleaned["Date"]) == ["2023-01-02", "2023-01-03", "2023-01-05"]


def test_scaler_inverse_transform_reconstruction():
    prices = np.array([100.0, 150.0, 200.0, 250.0, 300.0], dtype=np.float32)
    preprocessor = StockDataPreprocessor(sequence_length=2)
    scaled = preprocessor.fit_transform_training_data(prices)

    assert scaled.min() == 0.0
    assert scaled.max() == 1.0

    inverted = preprocessor.inverse_transform(scaled)
    np.testing.assert_allclose(inverted, prices, rtol=1e-5)


def test_create_sequences_dimensions():
    data = np.arange(10, dtype=np.float32)
    seq_len = 3
    preprocessor = StockDataPreprocessor(sequence_length=seq_len)
    X, y, _ = preprocessor.create_sequences(data)

    # With 10 elements and sequence length 3: samples = 10 - 3 = 7
    assert X.shape == (7, 3, 1)
    assert y.shape == (7,)
    # First sequence should be [0, 1, 2] predicting 3
    np.testing.assert_array_equal(X[0].flatten(), [0, 1, 2])
    assert y[0] == 3
