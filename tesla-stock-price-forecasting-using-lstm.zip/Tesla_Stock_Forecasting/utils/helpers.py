"""
Visualization and Formatting Helpers for Tesla Stock Price Forecasting.
Produces interactive Plotly figures and static Matplotlib figures
styled for high-contrast dark fintech aesthetics.
"""

from pathlib import Path
from typing import Dict, Any, List, Optional
import numpy as np
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from config import (
    VISUALIZATIONS_DIR,
    THEME_NAVY_BG,
    THEME_CARD_BG,
    THEME_ACCENT_BLUE,
    THEME_SUCCESS_GREEN,
    THEME_DANGER_RED,
    THEME_TEXT_PRIMARY,
    THEME_TEXT_MUTED,
)

# Dark fintech layout template
PLOTLY_DARK_LAYOUT = dict(
    paper_bgcolor=THEME_CARD_BG,
    plot_bgcolor=THEME_CARD_BG,
    font=dict(color=THEME_TEXT_PRIMARY, family="JetBrains Mono, monospace, sans-serif"),
    xaxis=dict(
        gridcolor="#2A3859",
        showgrid=True,
        zerolinecolor="#2A3859",
        linecolor="#475569",
    ),
    yaxis=dict(
        gridcolor="#2A3859",
        showgrid=True,
        zerolinecolor="#2A3859",
        linecolor="#475569",
    ),
    legend=dict(
        bgcolor="rgba(28, 37, 65, 0.8)",
        bordercolor="#475569",
        borderwidth=1,
    ),
    margin=dict(l=40, r=40, t=50, b=40),
)


def create_historical_price_chart(df: pd.DataFrame) -> go.Figure:
    """Creates interactive historical TSLA price chart with volume subplot."""
    fig = make_subplots(
        rows=2,
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.08,
        subplot_titles=("TSLA Historical Closing Price (USD)", "Trading Volume"),
        row_heights=[0.7, 0.3],
    )

    # Price Line
    fig.add_trace(
        go.Scatter(
            x=df["Date"],
            y=df["Close"],
            mode="lines",
            name="TSLA Close",
            line=dict(color=THEME_ACCENT_BLUE, width=2),
            hovertemplate="<b>Date</b>: %{x}<br><b>Close</b>: $%{y:.2f}<extra></extra>",
        ),
        row=1,
        col=1,
    )

    # 50-day Moving Average if enough data
    if len(df) >= 50:
        ma50 = df["Close"].rolling(window=50).mean()
        fig.add_trace(
            go.Scatter(
                x=df["Date"],
                y=ma50,
                mode="lines",
                name="50-Day MA",
                line=dict(color="#F59E0B", width=1.5, dash="dot"),
                hovertemplate="<b>50-Day MA</b>: $%{y:.2f}<extra></extra>",
            ),
            row=1,
            col=1,
        )

    # Volume Bar
    colors = [
        THEME_SUCCESS_GREEN if df["Close"].iloc[i] >= df["Open"].iloc[i] else THEME_DANGER_RED
        for i in range(len(df))
    ]
    fig.add_trace(
        go.Bar(
            x=df["Date"],
            y=df["Volume"],
            name="Volume",
            marker=dict(color=colors, opacity=0.7),
            hovertemplate="<b>Date</b>: %{x}<br><b>Volume</b>: %{y:,.0f}<extra></extra>",
        ),
        row=2,
        col=1,
    )

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        height=550,
        title=dict(text="Tesla (TSLA) Historical Market Performance", x=0.02),
        hovermode="x unified",
    )
    fig.update_yaxes(title_text="Price (USD)", row=1, col=1)
    fig.update_yaxes(title_text="Shares Traded", row=2, col=1)
    return fig


def create_actual_vs_predicted_chart(
    dates: List[str],
    actual_prices: np.ndarray,
    predicted_prices: np.ndarray,
    title: str = "Tesla Closing Price: Actual vs LSTM Predicted (Test Period)",
) -> go.Figure:
    """Creates interactive comparison chart of Actual vs LSTM Predicted prices."""
    fig = go.Figure()

    # Actual Price
    fig.add_trace(
        go.Scatter(
            x=dates,
            y=actual_prices,
            mode="lines",
            name="Actual Close Price",
            line=dict(color="#10B981", width=2.5),
            hovertemplate="<b>Date</b>: %{x}<br><b>Actual</b>: $%{y:.2f}<extra></extra>",
        )
    )

    # Predicted Price
    fig.add_trace(
        go.Scatter(
            x=dates,
            y=predicted_prices,
            mode="lines",
            name="LSTM Predicted Price",
            line=dict(color="#F43F5E", width=2, dash="dash"),
            hovertemplate="<b>Date</b>: %{x}<br><b>Predicted</b>: $%{y:.2f}<extra></extra>",
        )
    )

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        height=500,
        title=dict(text=title, x=0.02),
        xaxis_title="Trading Session Date",
        yaxis_title="Stock Price (USD)",
        hovermode="x unified",
    )
    return fig


def create_training_loss_chart(
    history: Dict[str, List[float]],
) -> go.Figure:
    """Plots training and validation loss curves over completed epochs."""
    epochs = list(range(1, len(history.get("loss", [])) + 1))
    fig = go.Figure()

    fig.add_trace(
        go.Scatter(
            x=epochs,
            y=history.get("loss", []),
            mode="lines+markers",
            name="Training Loss (MSE)",
            line=dict(color=THEME_ACCENT_BLUE, width=2.5),
            marker=dict(size=5),
        )
    )

    if "val_loss" in history and history["val_loss"]:
        fig.add_trace(
            go.Scatter(
                x=epochs,
                y=history["val_loss"],
                mode="lines+markers",
                name="Validation Loss (MSE)",
                line=dict(color="#EC4899", width=2.5),
                marker=dict(size=5),
            )
        )

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        height=450,
        title=dict(text="LSTM Learning Curve: Mean Squared Error Across Epochs", x=0.02),
        xaxis_title="Epoch Number",
        yaxis_title="Loss (Mean Squared Error)",
        hovermode="x unified",
    )
    return fig


def create_metrics_comparison_chart(
    lstm_metrics: Dict[str, float],
    baseline_metrics: Dict[str, float],
) -> go.Figure:
    """Produces grouped bar chart comparing LSTM performance vs Naive Baseline."""
    categories = ["MAE (USD)", "RMSE (USD)"]
    lstm_vals = [lstm_metrics["mae"], lstm_metrics["rmse"]]
    base_vals = [baseline_metrics["mae"], baseline_metrics["rmse"]]

    fig = go.Figure(
        data=[
            go.Bar(
                name="LSTM Deep Learning Model",
                x=categories,
                y=lstm_vals,
                marker_color=THEME_ACCENT_BLUE,
                text=[f"${v:.2f}" for v in lstm_vals],
                textposition="auto",
            ),
            go.Bar(
                name="Naive Persistence Baseline (Tomorrow = Today)",
                x=categories,
                y=base_vals,
                marker_color="#F59E0B",
                text=[f"${v:.2f}" for v in base_vals],
                textposition="auto",
            ),
        ]
    )

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        barmode="group",
        height=420,
        title=dict(text="Model Evaluation: LSTM vs Persistence Baseline (Lower is Better)", x=0.02),
        yaxis_title="Error Magnitude (USD)",
    )
    return fig


def create_daily_returns_histogram(df: pd.DataFrame) -> go.Figure:
    """Plots histogram of daily percentage price changes."""
    df_calc = df.copy()
    df_calc["Pct_Change"] = df_calc["Close"].pct_change() * 100
    df_calc.dropna(subset=["Pct_Change"], inplace=True)

    fig = go.Figure(
        data=[
            go.Histogram(
                x=df_calc["Pct_Change"],
                nbinsx=60,
                marker_color="#8B5CF6",
                opacity=0.8,
            )
        ]
    )

    fig.update_layout(
        **PLOTLY_DARK_LAYOUT,
        height=420,
        title=dict(text="Distribution of Daily TSLA Price Movements (%)", x=0.02),
        xaxis_title="Daily Percentage Change (%)",
        yaxis_title="Frequency (Trading Days)",
    )
    return fig


def save_chart_image(fig: go.Figure, filename: str) -> None:
    """Optionally exports visualization figures to disk."""
    try:
        dest = VISUALIZATIONS_DIR / filename
        fig.write_image(str(dest))
    except Exception:
        # kaleido or orca not installed in minimal headless environments
        pass
