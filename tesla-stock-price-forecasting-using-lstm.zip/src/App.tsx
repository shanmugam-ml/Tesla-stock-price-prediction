/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { defaultEngine, LSTMEngine } from './services/lstmEngine';
import { DashboardPage, StockRecord } from './types';
import { Navigation } from './components/Navigation';
import { Header } from './components/Header';
import { HomePage } from './pages/HomePage';
import { MarketAnalysisPage } from './pages/MarketAnalysisPage';
import { ModelTrainingPage } from './pages/ModelTrainingPage';
import { StockPredictionPage } from './pages/StockPredictionPage';
import { ActualVsPredictedPage } from './pages/ActualVsPredictedPage';
import { ModelPerformancePage } from './pages/ModelPerformancePage';
import { AboutProjectPage } from './pages/AboutProjectPage';
import { PythonCodebasePage } from './pages/PythonCodebasePage';
import { UploadModal } from './components/UploadModal';

export default function App() {
  const [engine, setEngine] = useState<LSTMEngine>(defaultEngine);
  const [data, setData] = useState<StockRecord[]>(defaultEngine.getData());
  const [currentPage, setCurrentPage] = useState<DashboardPage>('home');
  const [isUploadOpen, setIsUploadOpen] = useState<boolean>(false);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [version, setVersion] = useState<number>(0); // Triggers re-render on training

  // Computed state
  const isTrained = engine.getIsTrained();
  const latestPrice = data.length ? data[data.length - 1].close : 394.14;
  const latestDate = data.length ? data[data.length - 1].date : '2026-11-11';

  // Evaluate model & next day prediction
  const { testPoints, metrics } = useMemo(() => {
    return engine.evaluateModel();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine, data, version]);

  const prediction = useMemo(() => {
    return engine.predictNextTradingDay();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [engine, data, version]);

  const history = engine.getTrainingHistory();

  // Export CSV
  const handleDownloadCSV = () => {
    let csv = 'Date,Open,High,Low,Close,Volume\n';
    data.forEach((r) => {
      csv += `${r.date},${r.open},${r.high},${r.low},${r.close},${r.volume}\n`;
    });
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'tesla_stock_tsla.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Custom data upload callback
  const handleCustomDataLoaded = (newData: StockRecord[]) => {
    const newEngine = new LSTMEngine(newData);
    setEngine(newEngine);
    setData(newData);
    setVersion((v) => v + 1);
  };

  // Sync Yahoo Finance action
  const handleSyncYahooFinance = async () => {
    setIsRefreshing(true);
    // Simulate live sync verification
    await new Promise((r) => setTimeout(r, 900));
    setIsRefreshing(false);
  };

  const handleTrainingComplete = () => {
    setVersion((v) => v + 1);
  };

  return (
    <div className="min-h-screen bg-[#0B132B] text-slate-100 flex flex-col md:flex-row antialiased selection:bg-[#3A86FF] selection:text-white">
      {/* Sidebar Navigation */}
      <Navigation
        currentPage={currentPage}
        onSelectPage={setCurrentPage}
        totalRecords={data.length}
        latestPrice={latestPrice}
        isTrained={isTrained}
        onOpenUploadModal={() => setIsUploadOpen(true)}
        onRefreshData={handleSyncYahooFinance}
        isRefreshing={isRefreshing}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        <Header
          currentPage={currentPage}
          latestDate={latestDate}
          onDownloadCSV={handleDownloadCSV}
          onSelectPage={setCurrentPage}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {currentPage === 'home' && (
            <HomePage
              data={data}
              prediction={prediction}
              isTrained={isTrained}
              onNavigate={setCurrentPage}
            />
          )}

          {currentPage === 'analysis' && (
            <MarketAnalysisPage
              data={data}
              onUploadClick={() => setIsUploadOpen(true)}
            />
          )}

          {currentPage === 'training' && (
            <ModelTrainingPage
              engine={engine}
              data={data}
              isTrained={isTrained}
              onTrainingComplete={handleTrainingComplete}
            />
          )}

          {currentPage === 'prediction' && (
            <StockPredictionPage
              prediction={prediction}
              isTrained={isTrained}
            />
          )}

          {currentPage === 'comparison' && (
            <ActualVsPredictedPage testPoints={testPoints} />
          )}

          {currentPage === 'performance' && (
            <ModelPerformancePage metrics={metrics} history={history} />
          )}

          {currentPage === 'about' && <AboutProjectPage />}

          {currentPage === 'codebase' && <PythonCodebasePage />}
        </main>
      </div>

      {/* Custom CSV Upload Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onDataLoaded={handleCustomDataLoaded}
      />
    </div>
  );
}
