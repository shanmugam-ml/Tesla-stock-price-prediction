export interface StockRecord {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface ScalerMeta {
  min: number;
  max: number;
}

export interface TrainingHistory {
  epochs: number[];
  loss: number[];
  val_loss: number[];
  mae: number[];
  val_mae: number[];
}

export interface PredictionResult {
  ticker: string;
  lastMarketDate: string;
  nextTradingDay: string;
  lastClosePrice: number;
  predictedNextClose: number;
  priceDifference: number;
  percentChange: number;
  direction: 'BULLISH' | 'BEARISH';
  generationTimestamp: string;
  lookbackPeriod: number;
  disclaimer: string;
  recentSequence: number[];
  recentDates: string[];
}

export interface ModelMetrics {
  mae: number;
  mse: number;
  rmse: number;
  mape: number;
}

export interface ComparisonMetrics {
  lstm: ModelMetrics;
  baseline: ModelMetrics;
  improvementMaePct: number;
  improvementRmsePct: number;
}

export interface TestPredictionPoint {
  date: string;
  actual: number;
  predicted: number;
  error: number;
  absPctError: number;
}

export type DashboardPage =
  | 'home'
  | 'analysis'
  | 'training'
  | 'prediction'
  | 'comparison'
  | 'performance'
  | 'about'
  | 'codebase';
