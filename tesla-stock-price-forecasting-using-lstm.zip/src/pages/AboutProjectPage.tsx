import React from 'react';
import {
  FileText,
  Target,
  Layers,
  Cpu,
  Database,
  AlertTriangle,
  Lightbulb,
  Workflow,
  CheckCircle2,
} from 'lucide-react';

export const AboutProjectPage: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Abstract Header */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl">
        <div className="flex items-center gap-3 pb-3 border-b border-[#2A3859]">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-[#3A86FF]">
            <FileText size={22} />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Project Overview & Abstract</h3>
            <p className="text-xs text-slate-400">Deep Learning Time-Series Research on Tesla Inc. (TSLA)</p>
          </div>
        </div>

        <p className="text-sm text-slate-300 mt-4 leading-relaxed">
          Stock price forecasting is one of the most volatile and complex tasks in financial econometrics.
          Asset prices are dictated by complex non-linear interactions, macroeconomic indicators, and market psychology.
          This project demonstrates the complete engineering lifecycle of a Deep Learning application that utilizes
          a <b>Long Short-Term Memory (LSTM)</b> recurrent neural network to analyze historical Tesla market data
          and forecast the next trading day's closing price without lookahead data leakage.
        </p>
      </div>

      {/* Problem Statement & Objectives */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-rose-400 font-mono">
            <Target size={18} />
            <span>1. PROBLEM STATEMENT</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Standard regression techniques and naive heuristics treat financial observations as independent and identically
            distributed (i.i.d.), which fails in sequential market regimes. Meanwhile, simple Recurrent Neural Networks (RNNs)
            suffer from severe vanishing gradients over temporal lookback horizons.
          </p>
          <p className="text-xs text-slate-300 leading-relaxed">
            Our goal is to build a robust recurrent neural pipeline that learns from 60 consecutive trading days of price
            momentum to predict the subsequent closing session with empirical metric validation.
          </p>
        </div>

        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-emerald-400 font-mono">
            <CheckCircle2 size={18} />
            <span>2. PROJECT OBJECTIVES</span>
          </div>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside">
            <li>Retrieve authentic TSLA historical market data spanning 2015 to the present date.</li>
            <li>Enforce leak-free chronological 70% Train, 15% Validation, 15% Test data splitting.</li>
            <li>Fit normalization scalers strictly on training records.</li>
            <li>Implement 2-layer stacked LSTM architecture with Adam optimizer.</li>
            <li>Benchmark out-of-sample test results against persistence baselines.</li>
            <li>Provide an interactive fintech analytics terminal dashboard.</li>
          </ul>
        </div>
      </div>

      {/* 10-Stage Workflow */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-[#2A3859]">
          <Workflow size={18} className="text-[#3A86FF]" />
          <div>
            <h3 className="text-sm font-bold text-white">System Architecture: 10-Stage Lifecycle</h3>
            <p className="text-xs text-slate-400">End-to-end development sequence implemented in this project</p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 pt-2">
          {[
            { step: '01', title: 'Data Ingestion', desc: 'Auto-retrieval from Yahoo Finance & custom CSV validation.' },
            { step: '02', title: 'Cleaning & Deduplication', desc: 'Dropping null sessions, sorting chronologically.' },
            { step: '03', title: 'Chronological Splitting', desc: '70% Train, 15% Val, 15% Test partitions.' },
            { step: '04', title: 'Leak-Free Scaling', desc: 'MinMaxScaler fitted exclusively on training set.' },
            { step: '05', title: 'Sliding Sequences', desc: 'Rolling 60-day window tensor creation (N, 60, 1).' },
            { step: '06', title: 'LSTM Architecture', desc: '2-layer stacked LSTM (50+50) + Dense (25) + Linear.' },
            { step: '07', title: 'Training & Checkpoints', desc: 'MSE optimization, early stopping, .keras save.' },
            { step: '08', title: 'Out-of-Sample Test', desc: 'Inference on test partition and inverse transform.' },
            { step: '09', title: 'Metric Evaluation', desc: 'MAE, MSE, RMSE vs Naive Persistence Baseline.' },
            { step: '10', title: 'Terminal Dashboard', desc: 'Interactive dark fintech UI with Plotly visualizations.' },
          ].map((s) => (
            <div key={s.step} className="p-3 rounded-lg bg-[#0B132B] border border-[#2A3859]">
              <span className="text-[10px] font-mono text-[#3A86FF] font-bold">STAGE {s.step}</span>
              <h4 className="text-xs font-bold text-white mt-0.5">{s.title}</h4>
              <p className="text-[11px] text-slate-400 mt-1 leading-normal">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Limitations & Future Roadmap */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-amber-400 font-mono">
            <AlertTriangle size={18} />
            <span>LIMITATIONS & MARKET REALITIES</span>
          </div>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside leading-relaxed">
            <li><b>Exogenous Events:</b> Neural networks cannot foresee unscheduled political decisions, interest rate shifts, or breaking corporate headlines.</li>
            <li><b>High Beta Volatility:</b> Tesla is an exceptionally volatile asset with sharp momentum swings.</li>
            <li><b>Not Financial Advice:</b> Model forecasts are scientific momentum extrapolations, never guaranteed trading returns.</li>
          </ul>
        </div>

        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-3">
          <div className="flex items-center gap-2 text-sm font-bold text-blue-400 font-mono">
            <Lightbulb size={18} />
            <span>FUTURE ENHANCEMENTS ROADMAP</span>
          </div>
          <ul className="text-xs text-slate-300 space-y-2 list-disc list-inside leading-relaxed">
            <li><b>Multi-Variate Inputs:</b> Incorporating Volume, Open, High, Low, and technical indicators (RSI, MACD, Bollinger Bands).</li>
            <li><b>Multi-Step Horizons:</b> 5-day and 30-day forward trajectory prediction.</li>
            <li><b>LLM News Sentiment:</b> Ingesting financial news headlines via Google Gemini API to weight predictions with qualitative sentiment scores.</li>
            <li><b>Architectural Benchmarking:</b> Comparative evaluation with GRU, BiLSTM, and Temporal Convolutional Networks (TCN).</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
