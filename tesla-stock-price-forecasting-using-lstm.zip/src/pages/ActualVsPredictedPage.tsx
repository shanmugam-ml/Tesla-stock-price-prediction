import React, { useState, useMemo } from 'react';
import { GitCompare, Search, ChevronLeft, ChevronRight, TrendingUp, Filter } from 'lucide-react';
import { TestPredictionPoint } from '../types';
import { ActualVsPredictedChart } from '../components/Charts';

interface ActualVsPredictedPageProps {
  testPoints: TestPredictionPoint[];
}

export const ActualVsPredictedPage: React.FC<ActualVsPredictedPageProps> = ({ testPoints }) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 15;

  const filteredPoints = useMemo(() => {
    if (!searchTerm.trim()) return testPoints;
    return testPoints.filter((pt) => pt.date.includes(searchTerm.trim()));
  }, [testPoints, searchTerm]);

  const totalPages = Math.ceil(filteredPoints.length / pageSize) || 1;
  const paginatedPoints = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    // Show most recent test sessions first
    return [...filteredPoints].reverse().slice(start, start + pageSize);
  }, [filteredPoints, currentPage]);

  // Overall test set stats
  const testStats = useMemo(() => {
    if (!testPoints.length) return null;
    const errors = testPoints.map((p) => p.error);
    const absErrors = testPoints.map((p) => Math.abs(p.error));
    const meanError = errors.reduce((a, b) => a + b, 0) / errors.length;
    const maxError = Math.max(...absErrors);
    const minError = Math.min(...absErrors);

    return {
      meanError,
      maxError,
      minError,
      totalTestDays: testPoints.length,
    };
  }, [testPoints]);

  return (
    <div className="space-y-6">
      {/* Overview Banner */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <GitCompare size={18} className="text-[#3A86FF]" />
            Out-of-Sample Test Set Comparison ({testPoints.length} Sessions)
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Evaluating generalization capability on chronological data unseen during training
          </p>
        </div>

        {testStats && (
          <div className="flex items-center gap-3 text-xs font-mono">
            <div className="bg-[#0B132B] px-3 py-1.5 rounded-lg border border-[#2A3859]">
              <span className="text-slate-400">Mean Bias: </span>
              <span className={`font-bold ${testStats.meanError >= 0 ? 'text-amber-400' : 'text-cyan-400'}`}>
                {testStats.meanError >= 0 ? '+' : ''}${testStats.meanError.toFixed(2)}
              </span>
            </div>
            <div className="bg-[#0B132B] px-3 py-1.5 rounded-lg border border-[#2A3859]">
              <span className="text-slate-400">Max Error: </span>
              <span className="text-rose-400 font-bold">${testStats.maxError.toFixed(2)}</span>
            </div>
          </div>
        )}
      </div>

      {/* Main Dual-Series Interactive Chart */}
      <ActualVsPredictedChart data={testPoints} height={480} />

      {/* Individual Prediction Inspector Table */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-[#2A3859]">
          <div>
            <h3 className="text-base font-bold text-white">Test Session Prediction Inspector</h3>
            <p className="text-xs text-slate-400">Row-by-row inspection of actual vs predicted closes and residual spread</p>
          </div>

          <div className="flex items-center gap-2 bg-[#0B132B] px-3 py-1.5 rounded-lg border border-[#2A3859] text-xs">
            <Search size={14} className="text-slate-400" />
            <input
              type="text"
              placeholder="Search date (YYYY-MM)..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-transparent text-white outline-none w-48 text-xs font-mono"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0B132B] text-slate-400 uppercase text-[10px] border-y border-[#2A3859]">
              <tr>
                <th className="py-2.5 px-4 font-bold">Session Date</th>
                <th className="py-2.5 px-4 font-bold">Actual Close (USD)</th>
                <th className="py-2.5 px-4 font-bold">LSTM Predicted (USD)</th>
                <th className="py-2.5 px-4 font-bold">Residual Error</th>
                <th className="py-2.5 px-4 font-bold text-right">Abs % Error</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A3859]/50">
              {paginatedPoints.map((row) => {
                const isUnder = row.error < 0;
                return (
                  <tr key={row.date} className="hover:bg-[#253256]/50 transition-colors">
                    <td className="py-2.5 px-4 font-bold text-white">{row.date}</td>
                    <td className="py-2.5 px-4 font-bold text-emerald-400">${row.actual.toFixed(2)}</td>
                    <td className="py-2.5 px-4 font-bold text-rose-400">${row.predicted.toFixed(2)}</td>
                    <td className={`py-2.5 px-4 font-bold ${row.error >= 0 ? 'text-amber-400' : 'text-cyan-400'}`}>
                      {row.error >= 0 ? '+' : ''}${row.error.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-4 font-bold text-right text-purple-300">
                      {row.absPctError.toFixed(2)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Pagination Controls */}
        <div className="mt-4 pt-3 border-t border-[#2A3859] flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, filteredPoints.length)} of {filteredPoints.length} test records
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded bg-[#0B132B] hover:bg-[#2A3859] disabled:opacity-40 disabled:cursor-not-allowed border border-[#2A3859] text-white"
            >
              <ChevronLeft size={16} />
            </button>
            <span className="text-slate-300 px-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded bg-[#0B132B] hover:bg-[#2A3859] disabled:opacity-40 disabled:cursor-not-allowed border border-[#2A3859] text-white"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
