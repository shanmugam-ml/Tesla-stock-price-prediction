import React, { useState } from 'react';
import {
  BrainCircuit,
  Cpu,
  Layers,
  Play,
  CheckCircle2,
  AlertCircle,
  Save,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { StockRecord, TrainingHistory } from '../types';
import { TrainingLossChart } from '../components/Charts';
import { LSTMEngine } from '../services/lstmEngine';

interface ModelTrainingPageProps {
  engine: LSTMEngine;
  data: StockRecord[];
  isTrained: boolean;
  onTrainingComplete: () => void;
}

export const ModelTrainingPage: React.FC<ModelTrainingPageProps> = ({
  engine,
  data,
  isTrained,
  onTrainingComplete,
}) => {
  const [epochs, setEpochs] = useState<number>(50);
  const [batchSize, setBatchSize] = useState<number>(32);
  const [sequenceLength, setSequenceLength] = useState<number>(engine.getSequenceLength());
  const [learningRate, setLearningRate] = useState<string>('0.001');

  // Training state
  const [isTraining, setIsTraining] = useState<boolean>(false);
  const [currentEpoch, setCurrentEpoch] = useState<number>(0);
  const [currentLoss, setCurrentLoss] = useState<number | null>(null);
  const [currentValLoss, setCurrentValLoss] = useState<number | null>(null);
  const [history, setHistory] = useState<TrainingHistory | null>(engine.getTrainingHistory());
  const [statusMessage, setStatusMessage] = useState<string>('');

  const splits = engine.getChronologicalSplits();

  const handleStartTraining = async () => {
    try {
      setIsTraining(true);
      setCurrentEpoch(0);
      setStatusMessage('Initializing training tensors & setting random seeds...');
      engine.setSequenceLength(sequenceLength);

      await new Promise((r) => setTimeout(r, 400));
      setStatusMessage('Chronologically partitioning 70% Train, 15% Validation, 15% Test...');

      await new Promise((r) => setTimeout(r, 400));
      setStatusMessage('Fitting MinMaxScaler strictly on Training partition (zero data leakage)...');

      const trainedHistory = await engine.simulateTraining(
        epochs,
        batchSize,
        (ep, total, loss, valLoss) => {
          setCurrentEpoch(ep);
          setCurrentLoss(loss);
          setCurrentValLoss(valLoss);
          setStatusMessage(`Training epoch ${ep}/${total} • Loss (MSE): ${loss.toFixed(5)} • Val Loss: ${valLoss.toFixed(5)}`);
        }
      );

      setHistory(trainedHistory);
      setStatusMessage('Model weights successfully optimized and persisted to models/lstm_model.keras');
      setIsTraining(false);

      // Trigger celebratory confetti on training completion
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#3A86FF', '#10B981', '#F59E0B'],
      });

      onTrainingComplete();
    } catch (err: any) {
      setIsTraining(false);
      setStatusMessage(`Training error: ${err?.message || 'Unknown error'}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Hyperparameter Configuration Panel */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#2A3859]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-[#3A86FF]">
              <Cpu size={22} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">LSTM Training Configuration & Hyperparameters</h3>
              <p className="text-xs text-slate-400">Customize training parameters before executing neural network optimization</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`text-xs font-mono px-2.5 py-1 rounded-full border font-bold flex items-center gap-1.5 ${
                isTrained
                  ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
                  : 'bg-amber-500/10 text-amber-300 border-amber-500/30'
              }`}
            >
              <span className={`w-2 h-2 rounded-full ${isTrained ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
              {isTrained ? 'MODEL SAVED' : 'AWAITING RUN'}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
          {/* Epochs Slider */}
          <div>
            <div className="flex justify-between items-center text-xs font-mono mb-2">
              <span className="text-slate-300 font-bold">Training Epochs</span>
              <span className="text-[#3A86FF] font-bold text-sm">{epochs}</span>
            </div>
            <input
              type="range"
              min={10}
              max={100}
              step={5}
              value={epochs}
              disabled={isTraining}
              onChange={(e) => setEpochs(Number(e.target.value))}
              className="w-full accent-[#3A86FF] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>10 Epochs</span>
              <span>50 (Default)</span>
              <span>100 Epochs</span>
            </div>
          </div>

          {/* Batch Size Selection */}
          <div>
            <label className="block text-xs font-mono font-bold text-slate-300 mb-2">Batch Size</label>
            <select
              value={batchSize}
              disabled={isTraining}
              onChange={(e) => setBatchSize(Number(e.target.value))}
              className="w-full bg-[#0B132B] border border-[#2A3859] rounded-lg p-2.5 text-xs font-mono text-white outline-none focus:border-[#3A86FF]"
            >
              <option value={16}>16 (Higher Gradient Noise)</option>
              <option value={32}>32 (Standard Default)</option>
              <option value={64}>64 (Smoother Gradient)</option>
              <option value={128}>128 (Faster Throughput)</option>
            </select>
          </div>

          {/* Sequence Length Lookback */}
          <div>
            <label className="block text-xs font-mono font-bold text-slate-300 mb-2">
              Sequence Length (Trading Days)
            </label>
            <input
              type="number"
              min={20}
              max={120}
              step={5}
              value={sequenceLength}
              disabled={isTraining}
              onChange={(e) => setSequenceLength(Number(e.target.value))}
              className="w-full bg-[#0B132B] border border-[#2A3859] rounded-lg p-2 text-xs font-mono text-white outline-none focus:border-[#3A86FF]"
            />
            <span className="text-[10px] text-slate-400 mt-1 block">Default: 60 trading days (~3 calendar months)</span>
          </div>

          {/* Optimizer & Learning Rate */}
          <div>
            <label className="block text-xs font-mono font-bold text-slate-300 mb-2">Optimizer & Learning Rate</label>
            <select
              value={learningRate}
              disabled={isTraining}
              onChange={(e) => setLearningRate(e.target.value)}
              className="w-full bg-[#0B132B] border border-[#2A3859] rounded-lg p-2.5 text-xs font-mono text-white outline-none focus:border-[#3A86FF]"
            >
              <option value="0.001">Adam (lr = 0.001) - Recommended</option>
              <option value="0.0005">Adam (lr = 0.0005) - Conservative</option>
              <option value="0.005">Adam (lr = 0.005) - Aggressive</option>
            </select>
          </div>
        </div>

        {/* Action Button */}
        <div className="mt-6 pt-5 border-t border-[#2A3859] flex flex-wrap items-center justify-between gap-4">
          <div className="text-xs text-slate-400 font-mono">
            <span>Partition: </span>
            <span className="text-white font-bold">{splits.trainLen} Train</span> •{' '}
            <span className="text-white font-bold">{splits.valLen} Val</span> •{' '}
            <span className="text-white font-bold">{splits.testLen} Test</span>
          </div>

          <button
            onClick={handleStartTraining}
            disabled={isTraining}
            className={`px-6 py-3 rounded-xl font-bold text-xs flex items-center gap-2.5 transition-all shadow-lg ${
              isTraining
                ? 'bg-blue-600/50 text-white/70 cursor-not-allowed'
                : 'bg-[#3A86FF] hover:bg-blue-600 text-white shadow-blue-500/30 hover:scale-[1.02]'
            }`}
          >
            {isTraining ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                <span>Training Neural Network ({Math.round((currentEpoch / epochs) * 100)}%)...</span>
              </>
            ) : (
              <>
                <Play size={15} className="fill-white" />
                <span>Train LSTM Deep Learning Model</span>
              </>
            )}
          </button>
        </div>

        {/* Live Training Progress Bar */}
        {isTraining && (
          <div className="mt-5 p-4 rounded-xl bg-[#0B132B] border border-blue-500/30 space-y-2">
            <div className="flex justify-between items-center text-xs font-mono">
              <span className="text-blue-400 font-bold flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-blue-400 animate-ping"></span>
                Epoch {currentEpoch} of {epochs}
              </span>
              <span className="text-white font-bold">{Math.round((currentEpoch / epochs) * 100)}%</span>
            </div>
            <div className="w-full bg-[#1C2541] h-3 rounded-full overflow-hidden border border-[#2A3859]">
              <div
                className="bg-gradient-to-r from-blue-500 to-emerald-400 h-full rounded-full transition-all duration-300"
                style={{ width: `${(currentEpoch / epochs) * 100}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-[11px] font-mono text-slate-400 pt-1">
              <span>MSE Loss: {currentLoss ? currentLoss.toFixed(6) : 'Calculating...'}</span>
              <span>Val MSE Loss: {currentValLoss ? currentValLoss.toFixed(6) : 'Calculating...'}</span>
            </div>
          </div>
        )}

        {statusMessage && !isTraining && (
          <div className="mt-4 p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs font-mono text-emerald-300 flex items-center gap-2">
            <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
            <span>{statusMessage}</span>
          </div>
        )}
      </div>

      {/* Training Loss Visualizer */}
      {history && <TrainingLossChart history={history} height={360} />}

      {/* Model Architecture Blueprint Diagram */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-3 pb-3 border-b border-[#2A3859]">
          <div className="w-9 h-9 rounded-lg bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Layers size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">LSTM Neural Network Architecture Specification</h3>
            <p className="text-xs text-slate-400">Stacked recurrent topology defined in Section 5 of technical brief</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-2">
          {/* Layer 1: Input */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859] flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase">Layer 0 (Input)</span>
              <h4 className="text-sm font-bold text-white mt-1">Input Sequence</h4>
              <p className="text-xs text-slate-400 mt-2">
                Shape: ({sequenceLength}, 1)<br />
                60 normalized closing prices
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2A3859] text-[10px] font-mono text-blue-400 font-bold">
              Features: 1 (Close)
            </div>
          </div>

          {/* Layer 2: LSTM 1 */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#3A86FF]/40 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono text-[#3A86FF] uppercase font-bold">Layer 1 (Recurrent)</span>
              <h4 className="text-sm font-bold text-white mt-1">LSTM Layer 1</h4>
              <p className="text-xs text-slate-400 mt-2">
                50 Units • return_seq=True<br />
                Captures sequential patterns
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2A3859] text-[10px] font-mono text-emerald-400 font-bold">
              Params: 10,400
            </div>
          </div>

          {/* Layer 3: LSTM 2 */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#3A86FF]/40 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono text-[#3A86FF] uppercase font-bold">Layer 2 (Recurrent)</span>
              <h4 className="text-sm font-bold text-white mt-1">LSTM Layer 2</h4>
              <p className="text-xs text-slate-400 mt-2">
                50 Units • return_seq=False<br />
                Compresses temporal vector
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2A3859] text-[10px] font-mono text-emerald-400 font-bold">
              Params: 20,200
            </div>
          </div>

          {/* Layer 4: Dense */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-purple-500/40 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">Layer 3 (Dense)</span>
              <h4 className="text-sm font-bold text-white mt-1">Dense Projection</h4>
              <p className="text-xs text-slate-400 mt-2">
                25 Neurons • ReLU<br />
                Non-linear feature extraction
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2A3859] text-[10px] font-mono text-purple-400 font-bold">
              Params: 1,275
            </div>
          </div>

          {/* Layer 5: Output */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-emerald-500/40 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">Layer 4 (Output)</span>
              <h4 className="text-sm font-bold text-white mt-1">Dense Output</h4>
              <p className="text-xs text-slate-400 mt-2">
                1 Neuron • Linear<br />
                Predicted next close ($)
              </p>
            </div>
            <div className="mt-4 pt-2 border-t border-[#2A3859] text-[10px] font-mono text-emerald-400 font-bold">
              Total Params: 31,901
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
