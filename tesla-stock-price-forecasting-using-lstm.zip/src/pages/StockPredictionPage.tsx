import React from 'react';
import {
  TrendingUp,
  TrendingDown,
  Calendar,
  Clock,
  AlertTriangle,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  History,
  ShieldAlert,
} from 'lucide-react';
import { PredictionResult } from '../types';

interface StockPredictionPageProps {
  prediction: PredictionResult;
  isTrained: boolean;
}

export const StockPredictionPage: React.FC<StockPredictionPageProps> = ({
  prediction,
  isTrained,
}) => {
  const isUp = prediction.priceDifference >= 0;

  return (
    <div className="space-y-6">
      {/* Primary Forecast Hero Card */}
      <div className="bg-gradient-to-br from-[#1C2541] via-[#16213E] to-[#0B132B] border border-[#3A86FF]/50 rounded-2xl p-6 sm:p-10 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/30 text-[#3A86FF] text-xs font-mono font-bold mb-4">
          <Calendar size={14} />
          FORECAST TARGET SESSION: {prediction.nextTradingDay}
        </div>

        <h2 className="text-sm uppercase tracking-widest text-slate-400 font-mono">
          Predicted Next-Trading-Day Closing Price
        </h2>

        {/* Large Forecast Figure */}
        <div className="my-4 flex items-center justify-center gap-3">
          <span
            className={`text-4xl sm:text-6xl font-black font-mono tracking-tight ${
              isUp ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            ${prediction.predictedNextClose.toFixed(2)}
          </span>
          <span className="text-xl sm:text-2xl text-slate-400 font-mono font-semibold self-end mb-2">USD</span>
        </div>

        {/* Delta Pills */}
        <div className="inline-flex items-center gap-3 px-4 py-2 rounded-xl bg-[#0B132B] border border-[#2A3859] font-mono text-sm sm:text-base font-bold shadow-inner">
          <span className="flex items-center gap-1 text-slate-400 text-xs">Expected Movement:</span>
          <span className={`flex items-center gap-1 ${isUp ? 'text-emerald-400' : 'text-rose-400'}`}>
            {isUp ? <ArrowUpRight size={18} /> : <ArrowDownRight size={18} />}
            {isUp ? '+' : ''}${prediction.priceDifference.toFixed(2)} ({isUp ? '+' : ''}{prediction.percentChange.toFixed(2)}%)
          </span>
          <span
            className={`text-xs px-2 py-0.5 rounded font-bold ${
              isUp ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
            }`}
          >
            {prediction.direction}
          </span>
        </div>

        {/* Session Meta Subrow */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-8 pt-6 border-t border-[#2A3859]/80 text-xs font-mono text-slate-300">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Last Official Close</span>
            <span className="text-white font-bold text-sm">${prediction.lastClosePrice.toFixed(2)}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">({prediction.lastMarketDate})</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Next Regular Session</span>
            <span className="text-white font-bold text-sm">{prediction.nextTradingDay}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">(Excluding Weekends/Holidays)</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Prediction Timestamp</span>
            <span className="text-white font-bold text-sm">{prediction.generationTimestamp}</span>
            <span className="text-[10px] text-slate-400 block mt-0.5">Generated via LSTM Inference</span>
          </div>
        </div>
      </div>

      {/* Experimental Disclaimer Card */}
      <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-5 shadow-lg flex items-start gap-4">
        <ShieldAlert size={24} className="text-amber-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider font-mono">
            Mandatory Academic Research & Forecasting Disclaimer
          </h4>
          <p className="text-xs text-amber-200/80 leading-relaxed">
            {prediction.disclaimer}
          </p>
        </div>
      </div>

      {/* Input Sequence Inspector */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-[#2A3859]">
          <div className="flex items-center gap-2.5">
            <History size={18} className="text-[#3A86FF]" />
            <div>
              <h3 className="text-sm font-bold text-white">LSTM Input Tensor Sequence ({prediction.lookbackPeriod} Days)</h3>
              <p className="text-xs text-slate-400">
                The exact 60 rolling historical closing prices fed into the network input layer $(1, 60, 1)$
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-slate-400 bg-[#0B132B] px-3 py-1 rounded-lg border border-[#2A3859]">
            Shape: (1, {prediction.lookbackPeriod}, 1)
          </span>
        </div>

        {/* Mini Sparkline / Heat Bar of recent 60 sessions */}
        <div className="grid grid-cols-6 sm:grid-cols-10 md:grid-cols-12 gap-1.5 pt-2">
          {prediction.recentSequence.map((val, idx) => {
            const date = prediction.recentDates[idx];
            const isLatest = idx === prediction.recentSequence.length - 1;
            const minSeq = Math.min(...prediction.recentSequence);
            const maxSeq = Math.max(...prediction.recentSequence);
            const intensity = Math.round(((val - minSeq) / (maxSeq - minSeq || 1)) * 100);

            return (
              <div
                key={idx}
                title={`Session ${idx + 1} (${date}): $${val.toFixed(2)}`}
                className={`p-1.5 rounded text-center font-mono text-[10px] transition-all hover:scale-105 cursor-help border ${
                  isLatest
                    ? 'bg-[#3A86FF]/30 border-[#3A86FF] text-white font-bold'
                    : 'bg-[#0B132B] border-[#2A3859] text-slate-300'
                }`}
              >
                <div className="text-[8px] text-slate-400 truncate">t-{prediction.recentSequence.length - 1 - idx}</div>
                <div className="font-semibold">${val.toFixed(0)}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
