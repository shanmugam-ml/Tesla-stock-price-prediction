import React, { useState, useMemo } from 'react';
import { Search, ArrowUpDown, ChevronLeft, ChevronRight, Calendar, Filter } from 'lucide-react';
import { StockRecord } from '../types';
import { HistoricalPriceChart } from '../components/Charts';

interface MarketAnalysisPageProps {
  data: StockRecord[];
  onUploadClick: () => void;
}

export const MarketAnalysisPage: React.FC<MarketAnalysisPageProps> = ({ data, onUploadClick }) => {
  const [startDate, setStartDate] = useState<string>(data[0]?.date || '2015-01-02');
  const [endDate, setEndDate] = useState<string>(data[data.length - 1]?.date || '2026-11-11');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 15;

  // Filter data by custom date range
  const filteredData = useMemo(() => {
    return data.filter((d) => d.date >= startDate && d.date <= endDate);
  }, [data, startDate, endDate]);

  // Search in table
  const searchedData = useMemo(() => {
    if (!searchTerm.trim()) return filteredData;
    return filteredData.filter((d) => d.date.includes(searchTerm.trim()));
  }, [filteredData, searchTerm]);

  // Pagination
  const totalPages = Math.ceil(searchedData.length / pageSize) || 1;
  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    // Show newest first
    return [...searchedData].reverse().slice(start, start + pageSize);
  }, [searchedData, currentPage]);

  // Descriptive statistics for filtered range
  const stats = useMemo(() => {
    if (!filteredData.length) return null;
    const closes = filteredData.map((d) => d.close);
    const volumes = filteredData.map((d) => d.volume);
    const highs = filteredData.map((d) => d.high);
    const lows = filteredData.map((d) => d.low);

    const minClose = Math.min(...lows);
    const maxClose = Math.max(...highs);
    const avgClose = closes.reduce((a, b) => a + b, 0) / closes.length;
    const avgVolume = volumes.reduce((a, b) => a + b, 0) / volumes.length;

    // Daily percentage returns for volatility
    const returns: number[] = [];
    for (let i = 1; i < filteredData.length; i++) {
      returns.push(((filteredData[i].close - filteredData[i - 1].close) / filteredData[i - 1].close) * 100);
    }
    const meanReturn = returns.reduce((a, b) => a + b, 0) / (returns.length || 1);
    const variance = returns.reduce((a, r) => a + Math.pow(r - meanReturn, 2), 0) / (returns.length || 1);
    const dailyVolatility = Math.sqrt(variance);

    return {
      minClose,
      maxClose,
      avgClose,
      avgVolume,
      dailyVolatility,
      totalSessions: filteredData.length,
    };
  }, [filteredData]);

  return (
    <div className="space-y-6">
      {/* Date Range Control Bar */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Filter size={18} className="text-[#3A86FF]" />
          <div>
            <h3 className="text-sm font-bold text-white">Date Range Filtering</h3>
            <p className="text-xs text-slate-400">Select custom historical date boundary for OHLC analysis</p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 bg-[#0B132B] px-3 py-1.5 rounded-lg border border-[#2A3859] text-xs font-mono">
            <span className="text-slate-400">From:</span>
            <input
              type="date"
              value={startDate}
              min={data[0]?.date}
              max={endDate}
              onChange={(e) => {
                setStartDate(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-transparent text-white outline-none cursor-pointer"
            />
          </div>

          <div className="flex items-center gap-2 bg-[#0B132B] px-3 py-1.5 rounded-lg border border-[#2A3859] text-xs font-mono">
            <span className="text-slate-400">To:</span>
            <input
              type="date"
              value={endDate}
              min={startDate}
              max={data[data.length - 1]?.date}
              onChange={(e) => {
                setEndDate(e.target.value);
                setCurrentPage(1);
              }}
              className="bg-transparent text-white outline-none cursor-pointer"
            />
          </div>

          <button
            onClick={() => {
              setStartDate(data[0]?.date || '2015-01-02');
              setEndDate(data[data.length - 1]?.date || '2026-11-11');
              setCurrentPage(1);
            }}
            className="px-3 py-1.5 rounded-lg bg-[#253256] hover:bg-[#3A86FF] text-slate-200 hover:text-white text-xs font-mono font-medium transition-colors"
          >
            Reset All
          </button>
        </div>
      </div>

      {/* Main Interactive Historical Chart */}
      <HistoricalPriceChart data={filteredData} height={520} />

      {/* Summary Statistics */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-4 text-center">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Period High</div>
            <div className="text-lg font-bold font-mono text-emerald-400 mt-1">
              ${stats.maxClose.toFixed(2)}
            </div>
          </div>
          <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-4 text-center">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Period Low</div>
            <div className="text-lg font-bold font-mono text-rose-400 mt-1">
              ${stats.minClose.toFixed(2)}
            </div>
          </div>
          <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-4 text-center">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Average Close</div>
            <div className="text-lg font-bold font-mono text-[#3A86FF] mt-1">
              ${stats.avgClose.toFixed(2)}
            </div>
          </div>
          <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-4 text-center">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Avg Daily Volume</div>
            <div className="text-lg font-bold font-mono text-white mt-1">
              {(stats.avgVolume / 1e6).toFixed(1)}M
            </div>
          </div>
          <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-4 text-center">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Daily Volatility</div>
            <div className="text-lg font-bold font-mono text-amber-400 mt-1">
              {stats.dailyVolatility.toFixed(2)}%
            </div>
          </div>
          <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-4 text-center">
            <div className="text-[10px] font-mono text-slate-400 uppercase">Total Sessions</div>
            <div className="text-lg font-bold font-mono text-purple-400 mt-1">
              {stats.totalSessions.toLocaleString()}
            </div>
          </div>
        </div>
      )}

      {/* Historical Stock Data Table */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-[#2A3859]">
          <div>
            <h3 className="text-base font-bold text-white">Historical Stock Data Records</h3>
            <p className="text-xs text-slate-400">Authentic daily OHLCV trading logs chronologically ordered</p>
          </div>

          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 bg-[#0B132B] px-3 py-1.5 rounded-lg border border-[#2A3859] text-xs">
              <Search size={14} className="text-slate-400" />
              <input
                type="text"
                placeholder="Filter by date (YYYY-MM)..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-transparent text-white outline-none w-48 text-xs font-mono"
              />
            </div>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#0B132B] text-slate-400 uppercase text-[10px] border-y border-[#2A3859]">
              <tr>
                <th className="py-2.5 px-4 font-bold">Trading Date</th>
                <th className="py-2.5 px-4 font-bold">Open (USD)</th>
                <th className="py-2.5 px-4 font-bold">High (USD)</th>
                <th className="py-2.5 px-4 font-bold">Low (USD)</th>
                <th className="py-2.5 px-4 font-bold">Close (USD)</th>
                <th className="py-2.5 px-4 font-bold">Volume (Shares)</th>
                <th className="py-2.5 px-4 font-bold text-right">Daily Return</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#2A3859]/50">
              {paginatedData.map((row, idx) => {
                const diff = row.close - row.open;
                const pct = (diff / row.open) * 100;
                const isPositive = diff >= 0;
                return (
                  <tr key={row.date} className="hover:bg-[#253256]/50 transition-colors">
                    <td className="py-2.5 px-4 font-bold text-white">{row.date}</td>
                    <td className="py-2.5 px-4 text-slate-300">${row.open.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-emerald-400">${row.high.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-rose-400">${row.low.toFixed(2)}</td>
                    <td className="py-2.5 px-4 font-bold text-[#3A86FF]">${row.close.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-slate-300">{row.volume.toLocaleString()}</td>
                    <td className={`py-2.5 px-4 font-bold text-right ${isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {isPositive ? '+' : ''}{pct.toFixed(2)}%
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Table Pagination */}
        <div className="mt-4 pt-3 border-t border-[#2A3859] flex items-center justify-between text-xs font-mono">
          <span className="text-slate-400">
            Showing {(currentPage - 1) * pageSize + 1} to{' '}
            {Math.min(currentPage * pageSize, searchedData.length)} of {searchedData.length} records
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded bg-[#0B132B] hover:bg-[#2A3859] disabled:opacity-40 disabled:cursor-not-allowed border border-[#2A3859] text-white"
            >
              <ChevronLeft size={16} />
            </button>
            <span className="text-slate-300 px-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded bg-[#0B132B] hover:bg-[#2A3859] disabled:opacity-40 disabled:cursor-not-allowed border border-[#2A3859] text-white"
            >
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
