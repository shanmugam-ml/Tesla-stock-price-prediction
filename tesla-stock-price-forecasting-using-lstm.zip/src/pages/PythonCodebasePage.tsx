import React, { useState } from 'react';
import {
  Code2,
  Copy,
  Check,
  FileCode,
  Folder,
  Download,
  Terminal,
  ExternalLink,
} from 'lucide-react';

interface FileEntry {
  path: string;
  name: string;
  category: 'core' | 'src' | 'tests' | 'config';
  language: string;
  description: string;
  code: string;
}

export const PythonCodebasePage: React.FC = () => {
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);

  const files: FileEntry[] = [
    {
      path: 'app.py',
      name: 'app.py',
      category: 'core',
      language: 'python',
      description: 'Streamlit multi-page frontend dashboard and user interface application.',
      code: `"""
Streamlit Web Application: TESLA STOCK PRICE FORECASTING USING LSTM
A deep learning financial analytics dashboard implementing end-to-end data collection,
preprocessing, 2-layer LSTM modeling, next-trading-day forecasting, and performance evaluation.
"""

import sys
from pathlib import Path
import pandas as pd
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent
SRC_DIR = BASE_DIR / "src"
UTILS_DIR = BASE_DIR / "utils"
sys.path.extend([str(BASE_DIR), str(SRC_DIR), str(UTILS_DIR)])

from config import STOCK_TICKER, COMPANY_NAME, SAVED_MODEL_PATH, SEQUENCE_LENGTH
from data_collection import fetch_tesla_stock_data, get_latest_market_metadata
from preprocessing import StockDataPreprocessor
from model_training import train_lstm_model, load_saved_model
from prediction import predict_next_trading_day, predict_test_dataset
from evaluation import evaluate_lstm_vs_baseline
from helpers import create_historical_price_chart, create_actual_vs_predicted_chart

st.set_page_config(page_title="Tesla Stock Forecasting | LSTM", page_icon="📈", layout="wide")
st.title("Tesla Stock Price Forecasting Using LSTM")
# Run with: streamlit run app.py`,
    },
    {
      path: 'src/preprocessing.py',
      name: 'preprocessing.py',
      category: 'src',
      language: 'python',
      description: 'MinMaxScaler normalization strictly on training split, chronological train/val/test splits, and 60-day sequence tensor creation.',
      code: `"""
Data Preprocessing Module for Tesla Stock Forecasting.
Implements chronological train-validation-test split, MinMaxScaler fitting
strictly on training set (zero data leakage), sequential sliding window generation,
and inverse scaling back to USD.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from config import SEQUENCE_LENGTH, TARGET_COLUMN, TRAIN_SPLIT_RATIO, VAL_SPLIT_RATIO

class StockDataPreprocessor:
    def __init__(self, sequence_length: int = SEQUENCE_LENGTH):
        self.sequence_length = sequence_length
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.is_fitted = False

    def clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        df_clean = df.copy()
        df_clean["Date"] = pd.to_datetime(df_clean["Date"], errors="coerce")
        df_clean.dropna(subset=["Date", TARGET_COLUMN], inplace=True)
        df_clean.sort_values(by="Date", ascending=True, inplace=True)
        df_clean.drop_duplicates(subset=["Date"], keep="last", inplace=True)
        return df_clean.reset_index(drop=True)

    def fit_transform_training_data(self, train_series: np.ndarray) -> np.ndarray:
        scaled = self.scaler.fit_transform(train_series.reshape(-1, 1))
        self.is_fitted = True
        return scaled

    def transform(self, series: np.ndarray) -> np.ndarray:
        return self.scaler.transform(series.reshape(-1, 1))

    def inverse_transform(self, scaled: np.ndarray) -> np.ndarray:
        return self.scaler.inverse_transform(np.array(scaled).reshape(-1, 1)).flatten()

    def create_sequences(self, data: np.ndarray):
        X, y = [], []
        data_flat = data.flatten()
        for i in range(self.sequence_length, len(data_flat)):
            X.append(data_flat[i - self.sequence_length : i])
            y.append(data_flat[i])
        X_arr = np.array(X)
        return np.reshape(X_arr, (X_arr.shape[0], X_arr.shape[1], 1)), np.array(y)`,
    },
    {
      path: 'src/model_training.py',
      name: 'model_training.py',
      category: 'src',
      language: 'python',
      description: 'Stacked 2-layer LSTM deep learning architecture (50+50 units) + Dense(25) + Linear, with Adam and early stopping.',
      code: `"""
LSTM Deep Learning Model Architecture and Training Module.
Implements the stacked 2-layer LSTM neural network specified in Section 5
with Adam optimizer, early stopping, checkpointing, and .keras model serialization.
"""

import os
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Input
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint
from config import SEQUENCE_LENGTH, SAVED_MODEL_PATH, DEFAULT_EPOCHS, DEFAULT_BATCH_SIZE

def build_lstm_model(input_shape=(SEQUENCE_LENGTH, 1)):
    model = Sequential([
        Input(shape=input_shape, name="input_sequence"),
        LSTM(50, return_sequences=True, name="lstm_layer_1"),
        LSTM(50, return_sequences=False, name="lstm_layer_2"),
        Dense(25, activation="relu", name="dense_feature_extractor"),
        Dense(1, activation="linear", name="output_forecast"),
    ])
    model.compile(optimizer=Adam(learning_rate=0.001), loss="mean_squared_error", metrics=["mae"])
    return model

def train_lstm_model(X_train, y_train, X_val, y_val, epochs=DEFAULT_EPOCHS, batch_size=DEFAULT_BATCH_SIZE):
    model = build_lstm_model()
    callbacks = [
        EarlyStopping(monitor="val_loss", patience=10, restore_best_weights=True),
        ModelCheckpoint(filepath=str(SAVED_MODEL_PATH), monitor="val_loss", save_best_only=True)
    ]
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=epochs,
        batch_size=batch_size,
        callbacks=callbacks,
        shuffle=False
    )
    return model, history`,
    },
    {
      path: 'src/prediction.py',
      name: 'prediction.py',
      category: 'src',
      language: 'python',
      description: 'Next-trading-day closing price inference with weekend skipping and dollar delta calculations.',
      code: `"""
Stock Price Prediction Module for Next Trading Day Forecast.
Retrieves latest 60 trading days, normalizes with fitted scaler, runs forward inference,
converts back to USD, and calculates price movements with market calendar awareness.
"""

from datetime import datetime, timedelta
import numpy as np
from config import SEQUENCE_LENGTH

def get_next_trading_day(last_date_str: str) -> str:
    d = datetime.strptime(last_date_str, "%Y-%m-%d") + timedelta(days=1)
    if d.weekday() == 5:  # Saturday -> Monday
        d += timedelta(days=2)
    elif d.weekday() == 6:  # Sunday -> Monday
        d += timedelta(days=1)
    return d.strftime("%Y-%m-%d")

def predict_next_trading_day(model, preprocessor, df):
    clean_df = preprocessor.clean_data(df)
    last_60 = clean_df.iloc[-SEQUENCE_LENGTH:]["Close"].values.astype(np.float32)
    last_close = float(last_60[-1])
    last_date = str(clean_df.iloc[-1]["Date"])

    scaled = preprocessor.transform(last_60)
    inp = np.reshape(scaled, (1, SEQUENCE_LENGTH, 1))

    pred_scaled = model.predict(inp, verbose=0)
    pred_usd = float(preprocessor.inverse_transform(pred_scaled)[0])

    delta = pred_usd - last_close
    pct = (delta / last_close) * 100.0

    return {
        "ticker": "TSLA",
        "last_market_date": last_date,
        "next_trading_day": get_next_trading_day(last_date),
        "last_closing_price": round(last_close, 2),
        "predicted_next_close": round(pred_usd, 2),
        "price_difference": round(delta, 2),
        "percent_change": round(pct, 2),
        "direction": "BULLISH" if delta >= 0 else "BEARISH",
    }`,
    },
    {
      path: 'src/evaluation.py',
      name: 'evaluation.py',
      category: 'src',
      language: 'python',
      description: 'Evaluation metrics (MAE, MSE, RMSE) in original USD and comparative Naive Persistence Baseline.',
      code: `"""
Model Evaluation Module for Tesla Stock Forecasting.
Calculates MAE, MSE, RMSE on unscaled USD prices,
and benchmarks against a persistence baseline (Tomorrow's Close = Today's Close).
"""

import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error

def calculate_metrics(y_true_usd: np.ndarray, y_pred_usd: np.ndarray):
    mae = float(mean_absolute_error(y_true_usd, y_pred_usd))
    mse = float(mean_squared_error(y_true_usd, y_pred_usd))
    rmse = float(np.sqrt(mse))
    return {"mae": round(mae, 4), "mse": round(mse, 4), "rmse": round(rmse, 4)}

def calculate_persistence_baseline(actual_test_usd: np.ndarray):
    baseline_pred = actual_test_usd[:-1]
    baseline_true = actual_test_usd[1:]
    return baseline_pred, calculate_metrics(baseline_true, baseline_pred)`,
    },
    {
      path: 'config.py',
      name: 'config.py',
      category: 'config',
      language: 'python',
      description: 'Global configuration parameters, directory paths, and model hyperparameters.',
      code: `"""
Configuration settings for Tesla Stock Price Forecasting Using LSTM.
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
VISUALIZATIONS_DIR = BASE_DIR / "visualizations"

STOCK_TICKER = "TSLA"
COMPANY_NAME = "Tesla, Inc."
DEFAULT_START_DATE = "2015-01-01"
DEFAULT_CSV_PATH = DATA_DIR / "tesla_stock.csv"

SEQUENCE_LENGTH = 60
TARGET_COLUMN = "Close"
TRAIN_SPLIT_RATIO = 0.70
VAL_SPLIT_RATIO = 0.15
TEST_SPLIT_RATIO = 0.15

DEFAULT_EPOCHS = 50
DEFAULT_BATCH_SIZE = 32
SAVED_MODEL_PATH = MODELS_DIR / "lstm_model.keras"`,
    },
    {
      path: 'tests/test_preprocessing.py',
      name: 'test_preprocessing.py',
      category: 'tests',
      language: 'python',
      description: 'Unit tests for data sanitization, scaling, and sequence dimensionality.',
      code: `import numpy as np
import pandas as pd
from preprocessing import StockDataPreprocessor

def test_clean_data_handles_duplicates():
    df = pd.DataFrame({
        "Date": ["2023-01-05", "2023-01-02", "2023-01-02"],
        "Close": [105.0, 100.0, 100.0]
    })
    preprocessor = StockDataPreprocessor(sequence_length=2)
    cleaned = preprocessor.clean_data(df)
    assert len(cleaned) == 2

def test_scaler_inverse_transform():
    prices = np.array([100.0, 200.0, 300.0])
    p = StockDataPreprocessor(sequence_length=2)
    scaled = p.fit_transform_training_data(prices)
    inverted = p.inverse_transform(scaled)
    np.testing.assert_allclose(inverted, prices, rtol=1e-5)`,
    },
    {
      path: 'requirements.txt',
      name: 'requirements.txt',
      category: 'config',
      language: 'text',
      description: 'All required Python dependencies with compatible versions.',
      code: `tensorflow>=2.15.0
keras>=3.0.0
scikit-learn>=1.4.0
numpy>=1.24.0
pandas>=2.1.0
yfinance>=0.2.36
streamlit>=1.32.0
plotly>=5.19.0
matplotlib>=3.8.0
seaborn>=0.13.0
pytest>=8.0.0`,
    },
  ];

  const currentFile = files[selectedFileIndex];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Codebase Explorer Header */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-lg flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <Code2 size={18} className="text-[#3A86FF]" />
            Tesla_Stock_Forecasting / Python Source Modules
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Production-grade modular Python code ready to run locally with Streamlit & TensorFlow
          </p>
        </div>

        {/* Quick CLI command instructions */}
        <div className="flex items-center gap-2 bg-[#0B132B] px-3 py-1.5 rounded-lg border border-[#2A3859] text-xs font-mono text-slate-300">
          <Terminal size={14} className="text-emerald-400" />
          <span>streamlit run app.py</span>
        </div>
      </div>

      {/* Main File Browser & Code Viewer */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* File Tree Sidebar */}
        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-4 shadow-xl space-y-3">
          <div className="text-[10px] font-mono uppercase text-slate-400 tracking-wider font-bold px-2">
            Project Files ({files.length})
          </div>

          <div className="space-y-1">
            {files.map((file, idx) => {
              const isSelected = selectedFileIndex === idx;
              return (
                <button
                  key={file.path}
                  onClick={() => {
                    setSelectedFileIndex(idx);
                    setCopied(false);
                  }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-mono transition-colors text-left ${
                    isSelected
                      ? 'bg-[#3A86FF] text-white font-bold shadow-md shadow-blue-500/20'
                      : 'text-slate-300 hover:bg-[#253256] hover:text-white'
                  }`}
                >
                  <FileCode size={14} className={isSelected ? 'text-white' : 'text-[#3A86FF]'} />
                  <span className="flex-1 truncate">{file.name}</span>
                </button>
              );
            })}
          </div>

          <div className="pt-4 border-t border-[#2A3859] text-xs space-y-2">
            <div className="text-[10px] font-mono text-slate-400 uppercase font-bold">Local Setup</div>
            <div className="p-2.5 rounded bg-[#0B132B] text-[11px] font-mono text-slate-300 space-y-1 border border-[#2A3859]">
              <div>1. pip install -r requirements.txt</div>
              <div>2. pytest tests/ -v</div>
              <div>3. streamlit run app.py</div>
            </div>
          </div>
        </div>

        {/* Code Content Box */}
        <div className="lg:col-span-3 bg-[#1C2541] border border-[#2A3859] rounded-xl overflow-hidden shadow-xl flex flex-col">
          {/* File Tab Header */}
          <div className="bg-[#141C33] px-5 py-3 border-b border-[#2A3859] flex items-center justify-between">
            <div className="flex items-center gap-2 font-mono text-xs">
              <span className="text-[#3A86FF] font-bold">{currentFile.path}</span>
              <span className="text-slate-500">•</span>
              <span className="text-slate-400 text-[11px]">{currentFile.description}</span>
            </div>

            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1 rounded bg-[#0B132B] hover:bg-[#2A3859] text-slate-200 text-xs font-mono font-medium border border-[#2A3859] transition-colors"
            >
              {copied ? (
                <>
                  <Check size={13} className="text-emerald-400" />
                  <span className="text-emerald-400 font-bold">Copied!</span>
                </>
              ) : (
                <>
                  <Copy size={13} />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>

          {/* Syntax Code Container */}
          <div className="p-5 overflow-x-auto bg-[#0B132B] flex-1">
            <pre className="text-xs font-mono leading-relaxed text-slate-200">
              <code>{currentFile.code}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
