import React from 'react';
import {
  TrendingUp,
  BrainCircuit,
  Database,
  BarChart3,
  GitCompare,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Layers,
  Sparkles,
} from 'lucide-react';
import { StockRecord, PredictionResult, DashboardPage } from '../types';
import { HistoricalPriceChart } from '../components/Charts';

interface HomePageProps {
  data: StockRecord[];
  prediction: PredictionResult;
  isTrained: boolean;
  onNavigate: (page: DashboardPage) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  data,
  prediction,
  isTrained,
  onNavigate,
}) => {
  const latest = data[data.length - 1];
  const first = data[0];
  const allTimeChange = latest && first ? ((latest.close - first.close) / first.close) * 100 : 0;

  return (
    <div className="space-y-6">
      {/* Hero Welcome Banner */}
      <div className="bg-gradient-to-r from-[#1C2541] via-[#151D33] to-[#0B132B] border border-[#2A3859] rounded-2xl p-6 sm:p-8 relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-[#3A86FF] text-xs font-mono font-semibold mb-4">
            <Sparkles size={13} />
            DEEP LEARNING FINANCIAL ANALYTICS
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
            Tesla Stock Price Forecasting Using LSTM
          </h1>
          <p className="text-slate-300 text-sm sm:text-base mt-3 leading-relaxed">
            An end-to-end intelligent forecasting system that captures non-linear sequential price dynamics
            from authentic <b>Tesla, Inc. (TSLA)</b> market data. Harnessing a 2-layer stacked Long Short-Term
            Memory (LSTM) neural network with 60-day temporal lookback.
          </p>

          <div className="flex flex-wrap items-center gap-3 mt-6">
            <button
              onClick={() => onNavigate('prediction')}
              className="px-5 py-2.5 rounded-xl bg-[#3A86FF] hover:bg-blue-600 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-blue-500/30 transition-all hover:scale-[1.02]"
            >
              <TrendingUp size={16} />
              View Next-Day Forecast (${prediction.predictedNextClose.toFixed(2)})
            </button>
            <button
              onClick={() => onNavigate('training')}
              className="px-5 py-2.5 rounded-xl bg-[#0B132B] hover:bg-[#2A3859] text-slate-200 font-bold text-xs flex items-center gap-2 border border-[#2A3859] transition-all"
            >
              <BrainCircuit size={16} />
              Model Training Lab
            </button>
          </div>
        </div>
      </div>

      {/* Top KPI Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Ticker Info */}
        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Asset / Ticker</div>
          <div className="text-2xl font-extrabold font-mono text-white mt-1">TSLA</div>
          <div className="text-xs text-slate-300 mt-0.5">Tesla, Inc. • NASDAQ</div>
          <div className="mt-3 pt-3 border-t border-[#2A3859] flex items-center justify-between text-xs">
            <span className="text-slate-400">All-Time Gain:</span>
            <span className="font-mono font-bold text-emerald-400">+{allTimeChange.toFixed(1)}%</span>
          </div>
        </div>

        {/* Card 2: Latest Close */}
        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Latest Market Close</div>
          <div className="text-2xl font-extrabold font-mono text-[#3A86FF] mt-1">
            ${latest ? latest.close.toFixed(2) : '394.14'}
          </div>
          <div className="text-xs text-slate-300 mt-0.5">Session: {latest?.date}</div>
          <div className="mt-3 pt-3 border-t border-[#2A3859] flex items-center justify-between text-xs">
            <span className="text-slate-400">Day Range:</span>
            <span className="font-mono text-slate-300">${latest?.low.toFixed(2)} - ${latest?.high.toFixed(2)}</span>
          </div>
        </div>

        {/* Card 3: Next Day Forecast */}
        <div className="bg-[#1C2541] border border-[#3A86FF]/40 rounded-xl p-5 shadow-lg relative overflow-hidden bg-gradient-to-br from-[#1C2541] to-[#152247]">
          <div className="text-[11px] font-mono text-blue-300 uppercase tracking-wider flex items-center justify-between">
            <span>Forecast Next Close</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-blue-500/20 text-blue-300 border border-blue-400/30">
              {prediction.direction}
            </span>
          </div>
          <div className="text-2xl font-extrabold font-mono text-emerald-400 mt-1">
            ${prediction.predictedNextClose.toFixed(2)}
          </div>
          <div className="text-xs text-slate-300 mt-0.5">
            Delta: {prediction.priceDifference >= 0 ? '+' : ''}${prediction.priceDifference.toFixed(2)} ({prediction.percentChange >= 0 ? '+' : ''}{prediction.percentChange.toFixed(2)}%)
          </div>
          <div className="mt-3 pt-3 border-t border-[#2A3859] flex items-center justify-between text-xs">
            <span className="text-slate-400">Target Session:</span>
            <span className="font-mono text-white font-bold">{prediction.nextTradingDay}</span>
          </div>
        </div>

        {/* Card 4: Historical Records & Status */}
        <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-lg relative overflow-hidden">
          <div className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">Historical Records</div>
          <div className="text-2xl font-extrabold font-mono text-white mt-1">
            {data.length.toLocaleString()}
          </div>
          <div className="text-xs text-slate-300 mt-0.5">2015 to Present Sessions</div>
          <div className="mt-3 pt-3 border-t border-[#2A3859] flex items-center justify-between text-xs">
            <span className="text-slate-400">LSTM Model:</span>
            <span className="font-mono font-bold text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              {isTrained ? 'SAVED (.keras)' : 'PENDING'}
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Chart Preview */}
      <HistoricalPriceChart data={data} height={460} />

      {/* Why LSTM Section */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-[#3A86FF]">
            <BrainCircuit size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Why LSTM for Stock Price Forecasting?</h3>
            <p className="text-xs text-slate-400">Addressing temporal dependencies and the vanishing gradient dilemma</p>
          </div>
        </div>

        <p className="text-sm text-slate-300 leading-relaxed">
          Standard regression algorithms and simple feed-forward neural networks treat stock data observations as independent,
          failing to preserve sequential market memory. Standard Recurrent Neural Networks (RNNs) suffer from exponential gradient decay
          over long time horizons. Long Short-Term Memory (LSTM) solves this via three gating mechanisms inside specialized memory cells:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859]">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-rose-400 mb-1">
              <span>1. FORGET GATE</span>
            </div>
            <p className="text-xs text-slate-300 leading-normal">
              Applies a sigmoid filter (f_t = σ(W_f · [h_t-1, x_t] + b_f)) to discard obsolete price volatility
              and irrelevant historical noise from the cell state.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859]">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-blue-400 mb-1">
              <span>2. INPUT GATE</span>
            </div>
            <p className="text-xs text-slate-300 leading-normal">
              Determines what new incoming price information (i_t · C~_t) will be committed into the internal
              long-term memory state vector.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859]">
            <div className="flex items-center gap-2 text-xs font-mono font-bold text-emerald-400 mb-1">
              <span>3. OUTPUT GATE</span>
            </div>
            <p className="text-xs text-slate-300 leading-normal">
              Computes the filtered hidden state representation (h_t = o_t · tanh(C_t)) that passes into the dense layer
              to emit the next trading day's closing price.
            </p>
          </div>
        </div>
      </div>

      {/* Quick Navigation Cards */}
      <div>
        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider font-mono mb-3">
          Explore Dashboard Capabilities
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[
            {
              id: 'analysis' as DashboardPage,
              title: 'Market Analysis',
              desc: 'Interactive OHLC charts, moving averages, volume histograms, and data table.',
              icon: <BarChart3 className="text-[#3A86FF]" size={20} />,
            },
            {
              id: 'training' as DashboardPage,
              title: 'Model Training Lab',
              desc: 'Configure epochs, batch size, and train the 2-layer LSTM with real-time loss tracking.',
              icon: <Cpu className="text-purple-400" size={20} />,
            },
            {
              id: 'prediction' as DashboardPage,
              title: 'Price Prediction',
              desc: 'Next trading session forecast with dollar delta, percentage change, and calendar awareness.',
              icon: <TrendingUp className="text-emerald-400" size={20} />,
            },
            {
              id: 'comparison' as DashboardPage,
              title: 'Actual vs Predicted',
              desc: 'Test set ground truth vs model forecasts across 448 out-of-sample sessions.',
              icon: <GitCompare className="text-amber-400" size={20} />,
            },
            {
              id: 'performance' as DashboardPage,
              title: 'Model Performance',
              desc: 'MAE, MSE, and RMSE quantitative scores benchmarked against Naive Baseline.',
              icon: <Layers className="text-rose-400" size={20} />,
            },
            {
              id: 'codebase' as DashboardPage,
              title: 'Python Source Files',
              desc: 'Inspect modular Python architecture, Streamlit app.py, tests, and requirements.',
              icon: <ShieldCheck className="text-cyan-400" size={20} />,
            },
          ].map((card) => (
            <button
              key={card.id}
              onClick={() => onNavigate(card.id)}
              className="bg-[#1C2541] hover:bg-[#253256] border border-[#2A3859] hover:border-[#3A86FF]/50 rounded-xl p-5 text-left transition-all hover:scale-[1.01] flex flex-col justify-between group shadow-lg"
            >
              <div>
                <div className="w-10 h-10 rounded-lg bg-[#0B132B] border border-[#2A3859] flex items-center justify-center mb-3 group-hover:border-[#3A86FF] transition-colors">
                  {card.icon}
                </div>
                <h4 className="text-sm font-bold text-white group-hover:text-[#3A86FF] transition-colors">
                  {card.title}
                </h4>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">{card.desc}</p>
              </div>
              <div className="mt-4 flex items-center gap-1.5 text-xs font-mono text-[#3A86FF] font-semibold">
                <span>Open module</span>
                <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
