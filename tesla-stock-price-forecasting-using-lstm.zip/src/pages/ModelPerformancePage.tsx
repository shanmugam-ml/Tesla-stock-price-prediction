import React from 'react';
import {
  BarChart3,
  Award,
  TrendingDown,
  Info,
  CheckCircle2,
  Layers,
  ArrowDownRight,
} from 'lucide-react';
import { ComparisonMetrics, TrainingHistory } from '../types';
import { MetricsComparisonBarChart, TrainingLossChart } from '../components/Charts';

interface ModelPerformancePageProps {
  metrics: ComparisonMetrics;
  history: TrainingHistory | null;
}

export const ModelPerformancePage: React.FC<ModelPerformancePageProps> = ({
  metrics,
  history,
}) => {
  const { lstm, baseline, improvementMaePct, improvementRmsePct } = metrics;

  return (
    <div className="space-y-6">
      {/* Metric Scoreboard Header */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#2A3859]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Award size={22} />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Quantitative Performance & Benchmark Scoreboard</h3>
              <p className="text-xs text-slate-400">Rigorous out-of-sample evaluation calculated in original US Dollars (USD)</p>
            </div>
          </div>

          <span className="text-xs font-mono px-3 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1.5">
            <CheckCircle2 size={14} />
            Outperforms Naive Persistence
          </span>
        </div>

        {/* 3 Metric Hero Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          {/* Card 1: MAE */}
          <div className="p-5 rounded-xl bg-[#0B132B] border border-[#2A3859] relative overflow-hidden">
            <div className="flex justify-between items-center text-xs font-mono text-slate-400">
              <span>Mean Absolute Error (MAE)</span>
              <span className="text-emerald-400 font-bold">-{improvementMaePct}% vs Base</span>
            </div>
            <div className="text-3xl font-extrabold font-mono text-white mt-2">
              ${lstm.mae.toFixed(2)}
            </div>
            <div className="text-xs text-slate-400 mt-1 font-mono">
              Baseline: <span className="text-amber-400 font-bold">${baseline.mae.toFixed(2)} USD</span>
            </div>
            <div className="mt-3 pt-2 border-t border-[#2A3859] text-[11px] text-slate-400">
              Average absolute error per forecasted session.
            </div>
          </div>

          {/* Card 2: MSE */}
          <div className="p-5 rounded-xl bg-[#0B132B] border border-[#2A3859] relative overflow-hidden">
            <div className="flex justify-between items-center text-xs font-mono text-slate-400">
              <span>Mean Squared Error (MSE)</span>
              <span className="text-blue-400 font-bold">Squared Scale</span>
            </div>
            <div className="text-3xl font-extrabold font-mono text-white mt-2">
              {lstm.mse.toFixed(2)}
            </div>
            <div className="text-xs text-slate-400 mt-1 font-mono">
              Baseline: <span className="text-amber-400 font-bold">{baseline.mse.toFixed(2)}</span>
            </div>
            <div className="mt-3 pt-2 border-t border-[#2A3859] text-[11px] text-slate-400">
              Penalizes heavy outlier variance in volatile periods.
            </div>
          </div>

          {/* Card 3: RMSE */}
          <div className="p-5 rounded-xl bg-[#0B132B] border border-[#2A3859] relative overflow-hidden">
            <div className="flex justify-between items-center text-xs font-mono text-slate-400">
              <span>Root Mean Squared Error (RMSE)</span>
              <span className="text-emerald-400 font-bold">-{improvementRmsePct}% vs Base</span>
            </div>
            <div className="text-3xl font-extrabold font-mono text-[#3A86FF] mt-2">
              ${lstm.rmse.toFixed(2)}
            </div>
            <div className="text-xs text-slate-400 mt-1 font-mono">
              Baseline: <span className="text-amber-400 font-bold">${baseline.rmse.toFixed(2)} USD</span>
            </div>
            <div className="mt-3 pt-2 border-t border-[#2A3859] text-[11px] text-slate-400">
              Standard deviation of prediction residuals in USD.
            </div>
          </div>
        </div>
      </div>

      {/* Grouped Bar Comparison Chart */}
      <MetricsComparisonBarChart
        lstmMae={lstm.mae}
        lstmRmse={lstm.rmse}
        baseMae={baseline.mae}
        baseRmse={baseline.rmse}
      />

      {/* Loss Curves if available */}
      {history && <TrainingLossChart history={history} height={320} />}

      {/* Metric Mathematical Breakdown & Explanation */}
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-6 shadow-xl space-y-4">
        <div className="flex items-center gap-2.5 pb-3 border-b border-[#2A3859]">
          <Info size={18} className="text-[#3A86FF]" />
          <div>
            <h3 className="text-sm font-bold text-white">Evaluation Metric Definitions & Mathematical Formulations</h3>
            <p className="text-xs text-slate-400">Understanding error quantification in financial time-series econometric modeling</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2 text-xs">
          {/* MAE */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859] space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-mono font-bold text-[#3A86FF] text-sm">Mean Absolute Error (MAE)</span>
              <span className="font-mono text-[10px] text-slate-400">L1 LOSS</span>
            </div>
            <div className="p-2 rounded bg-[#1C2541] font-mono text-center text-slate-200 text-xs">
              MAE = (1 / n) * Σ |y_actual - y_pred|
            </div>
            <p className="text-slate-300 leading-relaxed">
              Computes the arithmetic average magnitude of forecast errors in linear terms without squaring.
              An MAE of ${lstm.mae.toFixed(2)} indicates that, on average, the LSTM predicted closing price deviates
              by ${lstm.mae.toFixed(2)} from the true market close.
            </p>
          </div>

          {/* RMSE */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859] space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-mono font-bold text-[#3A86FF] text-sm">Root Mean Squared Error (RMSE)</span>
              <span className="font-mono text-[10px] text-slate-400">L2 ROOT LOSS</span>
            </div>
            <div className="p-2 rounded bg-[#1C2541] font-mono text-center text-slate-200 text-xs">
              RMSE = √[(1 / n) * Σ (y_actual - y_pred)²]
            </div>
            <p className="text-slate-300 leading-relaxed">
              Calculates the square root of mean squared error. Because discrepancies are squared prior to averaging,
              RMSE assigns disproportionate penalties to large single-day forecasting misses (e.g. quarterly earnings volatility).
            </p>
          </div>

          {/* Persistence Baseline */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859] space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-mono font-bold text-amber-400 text-sm">Persistence Baseline (Naive Walk)</span>
              <span className="font-mono text-[10px] text-slate-400">BENCHMARK</span>
            </div>
            <div className="p-2 rounded bg-[#1C2541] font-mono text-center text-slate-200 text-xs">
              Forecast(t+1) = Actual(t)
            </div>
            <p className="text-slate-300 leading-relaxed">
              In financial econometrics, tomorrow’s price often closely mirrors today’s price due to efficient market dynamics.
              The persistence model serves as the gold-standard acid test: an algorithmic model must demonstrate lower error
              than this simple persistence assumption to prove genuine pattern learning.
            </p>
          </div>

          {/* MAPE */}
          <div className="p-4 rounded-xl bg-[#0B132B] border border-[#2A3859] space-y-2">
            <div className="flex justify-between items-center">
              <span className="font-mono font-bold text-purple-400 text-sm">Mean Absolute Percentage Error</span>
              <span className="font-mono text-[10px] text-slate-400">MAPE</span>
            </div>
            <div className="p-2 rounded bg-[#1C2541] font-mono text-center text-slate-200 text-xs">
              MAPE = (100% / n) * Σ |(y_actual - y_pred) / y_actual|
            </div>
            <p className="text-slate-300 leading-relaxed">
              Expresses the forecast error relative to actual closing prices as a percentage. The LSTM model achieves an
              out-of-sample MAPE of <b>{lstm.mape.toFixed(2)}%</b>, confirming high relative accuracy across varied stock price ranges.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
