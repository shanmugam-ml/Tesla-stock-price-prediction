import React from 'react';
import {
  LayoutDashboard,
  LineChart,
  BrainCircuit,
  TrendingUp,
  GitCompare,
  BarChart3,
  Info,
  Code2,
  Database,
  UploadCloud,
  CheckCircle2,
} from 'lucide-react';
import { DashboardPage } from '../types';

interface NavigationProps {
  currentPage: DashboardPage;
  onSelectPage: (page: DashboardPage) => void;
  totalRecords: number;
  latestPrice: number;
  isTrained: boolean;
  onOpenUploadModal: () => void;
  onRefreshData: () => void;
  isRefreshing: boolean;
}

export const Navigation: React.FC<NavigationProps> = ({
  currentPage,
  onSelectPage,
  totalRecords,
  latestPrice,
  isTrained,
  onOpenUploadModal,
  onRefreshData,
  isRefreshing,
}) => {
  const menuItems: { id: DashboardPage; label: string; icon: React.ReactNode; num: string }[] = [
    { id: 'home', label: 'Home Dashboard', icon: <LayoutDashboard size={18} />, num: '1' },
    { id: 'analysis', label: 'Stock Market Analysis', icon: <LineChart size={18} />, num: '2' },
    { id: 'training', label: 'LSTM Model Training', icon: <BrainCircuit size={18} />, num: '3' },
    { id: 'prediction', label: 'Stock Price Prediction', icon: <TrendingUp size={18} />, num: '4' },
    { id: 'comparison', label: 'Actual vs Predicted', icon: <GitCompare size={18} />, num: '5' },
    { id: 'performance', label: 'Model Performance', icon: <BarChart3 size={18} />, num: '6' },
    { id: 'about', label: 'About Project', icon: <Info size={18} />, num: '7' },
    { id: 'codebase', label: 'Python Source Files', icon: <Code2 size={18} />, num: '8' },
  ];

  return (
    <aside className="w-64 bg-[#1C2541] border-r border-[#2A3859] flex flex-col h-screen sticky top-0 shrink-0 z-30 select-none">
      {/* Brand Header */}
      <div className="p-5 border-b border-[#2A3859]">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#3A86FF] flex items-center justify-center text-white font-bold shadow-lg shadow-blue-500/30">
            ⚡
          </div>
          <div>
            <h1 className="font-extrabold text-sm text-white tracking-wider font-mono">TSLA FORECAST</h1>
            <p className="text-[11px] text-[#3A86FF] font-medium">LSTM Deep Learning</p>
          </div>
        </div>

        {/* Live Ticker Mini-Pill */}
        <div className="mt-4 p-2.5 rounded-lg bg-[#0B132B] border border-[#2A3859] flex items-center justify-between">
          <div>
            <span className="text-[10px] text-slate-400 font-mono block">NASDAQ: TSLA</span>
            <span className="text-white font-bold font-mono text-sm">${latestPrice.toFixed(2)}</span>
          </div>
          <span className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            LIVE
          </span>
        </div>
      </div>

      {/* Navigation Pages */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1">
        <div className="px-3 py-1.5 text-[10px] uppercase tracking-wider font-mono text-slate-400 font-bold">
          Dashboard Pages
        </div>

        {menuItems.map((item) => {
          const isActive = currentPage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectPage(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all text-left ${
                isActive
                  ? 'bg-[#3A86FF] text-white shadow-md shadow-blue-600/30 font-bold'
                  : 'text-slate-300 hover:text-white hover:bg-[#253256]'
              }`}
            >
              <span className={`shrink-0 ${isActive ? 'text-white' : 'text-slate-400'}`}>
                {item.icon}
              </span>
              <span className="flex-1 truncate">{item.label}</span>
              <span
                className={`text-[10px] font-mono px-1.5 py-0.5 rounded ${
                  isActive ? 'bg-white/20 text-white' : 'bg-[#0B132B] text-slate-400'
                }`}
              >
                P{item.num}
              </span>
            </button>
          );
        })}

        {/* Data Source Action Box */}
        <div className="pt-4 mt-3 border-t border-[#2A3859]">
          <div className="px-3 py-1 text-[10px] uppercase tracking-wider font-mono text-slate-400 font-bold">
            Data Collection
          </div>
          <div className="p-2.5 mt-1 rounded-lg bg-[#0B132B] border border-[#2A3859] space-y-2 text-xs">
            <div className="flex items-center justify-between text-[11px]">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Database size={13} className="text-[#3A86FF]" />
                Dataset
              </span>
              <span className="text-white font-mono font-semibold">{totalRecords.toLocaleString()} rows</span>
            </div>

            <button
              onClick={onOpenUploadModal}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded bg-[#1C2541] hover:bg-[#2A3859] text-slate-200 text-[11px] font-medium border border-[#2A3859] transition-colors"
            >
              <UploadCloud size={13} className="text-blue-400" />
              Upload Custom CSV
            </button>

            <button
              onClick={onRefreshData}
              disabled={isRefreshing}
              className="w-full flex items-center justify-center gap-1.5 py-1.5 px-2 rounded bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 text-[11px] font-medium border border-blue-500/30 transition-colors"
            >
              <span className={isRefreshing ? 'animate-spin' : ''}>↻</span>
              {isRefreshing ? 'Updating...' : 'Sync Yahoo Finance'}
            </button>
          </div>
        </div>
      </div>

      {/* Model Status Footer */}
      <div className="p-3 border-t border-[#2A3859] bg-[#141C33]">
        <div className="flex items-center justify-between text-[11px]">
          <span className="text-slate-400 flex items-center gap-1.5">
            <CheckCircle2 size={13} className={isTrained ? 'text-emerald-400' : 'text-amber-400'} />
            LSTM Checkpoint
          </span>
          <span
            className={`font-mono text-[10px] font-bold px-1.5 py-0.5 rounded ${
              isTrained
                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
            }`}
          >
            {isTrained ? 'TRAINED' : 'UNTRAINED'}
          </span>
        </div>
        <p className="text-[10px] text-slate-400 font-mono mt-1 truncate">
          models/lstm_model.keras
        </p>
      </div>
    </aside>
  );
};
