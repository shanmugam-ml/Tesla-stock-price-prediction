import React, { useState, useMemo } from 'react';
import { StockRecord, TestPredictionPoint, TrainingHistory } from '../types';

interface HistoricalChartProps {
  data: StockRecord[];
  height?: number;
}

export const HistoricalPriceChart: React.FC<HistoricalChartProps> = ({ data, height = 480 }) => {
  const [range, setRange] = useState<'1M' | '6M' | '1Y' | '3Y' | '5Y' | 'ALL'>('1Y');
  const [showMA50, setShowMA50] = useState<boolean>(true);
  const [showMA200, setShowMA200] = useState<boolean>(true);
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  // Filter data based on selected range
  const filteredData = useMemo(() => {
    if (!data.length) return [];
    const count = data.length;
    let sliceLen = count;
    if (range === '1M') sliceLen = Math.min(22, count);
    else if (range === '6M') sliceLen = Math.min(126, count);
    else if (range === '1Y') sliceLen = Math.min(252, count);
    else if (range === '3Y') sliceLen = Math.min(756, count);
    else if (range === '5Y') sliceLen = Math.min(1260, count);

    return data.slice(count - sliceLen);
  }, [data, range]);

  // Compute 50-day and 200-day Moving Averages
  const { closes, ma50, ma200, volumes, dates } = useMemo(() => {
    const c = filteredData.map((d) => d.close);
    const v = filteredData.map((d) => d.volume);
    const d = filteredData.map((x) => x.date);

    const m50 = c.map((_, idx) => {
      if (idx < 49) return null;
      const window = c.slice(idx - 49, idx + 1);
      return window.reduce((a, b) => a + b, 0) / 50;
    });

    const m200 = c.map((_, idx) => {
      if (idx < 199) return null;
      const window = c.slice(idx - 199, idx + 1);
      return window.reduce((a, b) => a + b, 0) / 200;
    });

    return { closes: c, ma50: m50, ma200: m200, volumes: v, dates: d };
  }, [filteredData]);

  if (!filteredData.length) {
    return <div className="p-8 text-center text-slate-400">No market data available to render chart.</div>;
  }

  // Dimension computations
  const paddingLeft = 55;
  const paddingRight = 20;
  const paddingTop = 25;
  const priceHeight = height * 0.65;
  const volumeHeight = height * 0.22;
  const gap = height * 0.05;
  const volumeTop = paddingTop + priceHeight + gap;
  const width = 800; // SVG coordinate viewBox width

  const minPrice = Math.min(...closes) * 0.96;
  const maxPrice = Math.max(...closes) * 1.04;
  const priceRange = maxPrice - minPrice || 1;

  const maxVolume = Math.max(...volumes) * 1.1 || 1;

  const getX = (idx: number) => {
    const usableWidth = width - paddingLeft - paddingRight;
    return paddingLeft + (idx / (filteredData.length - 1 || 1)) * usableWidth;
  };

  const getYPrice = (val: number) => {
    const ratio = (val - minPrice) / priceRange;
    return paddingTop + priceHeight - ratio * priceHeight;
  };

  const getYVolume = (vol: number) => {
    const ratio = vol / maxVolume;
    return volumeTop + volumeHeight - ratio * volumeHeight;
  };

  // Build SVG path strings
  const pricePath = filteredData
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i).toFixed(1)} ${getYPrice(d.close).toFixed(1)}`)
    .join(' ');

  const areaPath = `${pricePath} L ${getX(filteredData.length - 1).toFixed(1)} ${(paddingTop + priceHeight).toFixed(1)} L ${getX(0).toFixed(1)} ${(paddingTop + priceHeight).toFixed(1)} Z`;

  // MA paths
  const ma50Path = ma50
    .map((val, i) => {
      if (val === null) return '';
      const prefix = i === 49 || ma50[i - 1] === null ? 'M' : 'L';
      return `${prefix} ${getX(i).toFixed(1)} ${getYPrice(val).toFixed(1)}`;
    })
    .filter(Boolean)
    .join(' ');

  const ma200Path = ma200
    .map((val, i) => {
      if (val === null) return '';
      const prefix = i === 199 || ma200[i - 1] === null ? 'M' : 'L';
      return `${prefix} ${getX(i).toFixed(1)} ${getYPrice(val).toFixed(1)}`;
    })
    .filter(Boolean)
    .join(' ');

  const activePoint = hoverIndex !== null && hoverIndex >= 0 && hoverIndex < filteredData.length
    ? filteredData[hoverIndex]
    : filteredData[filteredData.length - 1];

  const activeIdx = hoverIndex !== null ? hoverIndex : filteredData.length - 1;

  return (
    <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-xl">
      {/* Chart Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-[#2A3859]">
        <div>
          <div className="flex items-center gap-3">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#3A86FF] animate-pulse"></span>
              TSLA Historical Price & Volume
            </h3>
            <span className="text-xs px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 font-mono font-medium">
              NASDAQ
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Hover over chart for session details • Range: {filteredData[0]?.date} to {filteredData[filteredData.length - 1]?.date}
          </p>
        </div>

        {/* Range Buttons and MA Toggles */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex bg-[#0B132B] p-1 rounded-lg border border-[#2A3859] text-xs font-mono">
            {(['1M', '6M', '1Y', '3Y', '5Y', 'ALL'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setRange(r)}
                className={`px-2.5 py-1 rounded transition-colors ${
                  range === r
                    ? 'bg-[#3A86FF] text-white font-bold'
                    : 'text-slate-400 hover:text-white hover:bg-[#1C2541]'
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              onClick={() => setShowMA50(!showMA50)}
              className={`px-2 py-1 rounded border transition-colors flex items-center gap-1.5 ${
                showMA50
                  ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
                  : 'bg-[#0B132B] border-[#2A3859] text-slate-500'
              }`}
            >
              <span className="w-2 h-0.5 bg-amber-400 inline-block"></span> 50 MA
            </button>
            <button
              onClick={() => setShowMA200(!showMA200)}
              className={`px-2 py-1 rounded border transition-colors flex items-center gap-1.5 ${
                showMA200
                  ? 'bg-purple-500/20 border-purple-500/40 text-purple-300'
                  : 'bg-[#0B132B] border-[#2A3859] text-slate-500'
              }`}
            >
              <span className="w-2 h-0.5 bg-purple-400 inline-block"></span> 200 MA
            </button>
          </div>
        </div>
      </div>

      {/* Live Hover Info Bar */}
      {activePoint && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-[#0B132B] p-3 rounded-lg border border-[#2A3859] mb-4 text-xs font-mono">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Session Date</span>
            <span className="text-white font-bold">{activePoint.date}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Close Price</span>
            <span className="text-[#3A86FF] font-bold text-sm">${activePoint.close.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Day Range (L - H)</span>
            <span className="text-slate-200">${activePoint.low.toFixed(2)} - ${activePoint.high.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Trading Volume</span>
            <span className="text-emerald-400 font-bold">{activePoint.volume.toLocaleString()}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Day Change</span>
            {(() => {
              const diff = activePoint.close - activePoint.open;
              const pct = (diff / activePoint.open) * 100;
              const isUp = diff >= 0;
              return (
                <span className={`font-bold ${isUp ? 'text-emerald-400' : 'text-red-400'}`}>
                  {isUp ? '+' : ''}${diff.toFixed(2)} ({isUp ? '+' : ''}{pct.toFixed(2)}%)
                </span>
              );
            })()}
          </div>
        </div>
      )}

      {/* Interactive SVG Chart */}
      <div className="relative w-full overflow-hidden select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto cursor-crosshair"
          onMouseMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const relX = ((e.clientX - rect.left) / rect.width) * width;
            const usableWidth = width - paddingLeft - paddingRight;
            const frac = Math.max(0, Math.min(1, (relX - paddingLeft) / usableWidth));
            const idx = Math.round(frac * (filteredData.length - 1));
            setHoverIndex(idx);
          }}
          onMouseLeave={() => setHoverIndex(null)}
        >
          <defs>
            <linearGradient id="priceGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#3A86FF" stopOpacity="0.45" />
              <stop offset="100%" stopColor="#3A86FF" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid lines & Y-axis labels for Price */}
          {[0, 0.25, 0.5, 0.75, 1].map((step, i) => {
            const y = paddingTop + priceHeight - step * priceHeight;
            const val = minPrice + step * priceRange;
            return (
              <g key={`grid-price-${i}`}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={width - paddingRight}
                  y2={y}
                  stroke="#2A3859"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={paddingLeft - 8}
                  y={y + 4}
                  fill="#94A3B8"
                  fontSize="10"
                  fontFamily="JetBrains Mono"
                  textAnchor="end"
                >
                  ${val.toFixed(0)}
                </text>
              </g>
            );
          })}

          {/* Price Area Fill */}
          <path d={areaPath} fill="url(#priceGradient)" />

          {/* Price Line */}
          <path d={pricePath} fill="none" stroke="#3A86FF" strokeWidth="2.2" strokeLinecap="round" />

          {/* 50 MA Line */}
          {showMA50 && ma50Path && (
            <path d={ma50Path} fill="none" stroke="#F59E0B" strokeWidth="1.6" strokeDasharray="4 2" />
          )}

          {/* 200 MA Line */}
          {showMA200 && ma200Path && (
            <path d={ma200Path} fill="none" stroke="#C084FC" strokeWidth="1.6" strokeDasharray="5 3" />
          )}

          {/* Volume bars separator line */}
          <line
            x1={paddingLeft}
            y1={volumeTop - 10}
            x2={width - paddingRight}
            y2={volumeTop - 10}
            stroke="#2A3859"
            strokeWidth="1"
          />
          <text
            x={paddingLeft}
            y={volumeTop - 2}
            fill="#64748B"
            fontSize="9"
            fontFamily="JetBrains Mono"
            textAnchor="start"
          >
            VOLUME (SHARES)
          </text>

          {/* Volume Bars */}
          {filteredData.map((d, i) => {
            const x = getX(i);
            const y = getYVolume(d.volume);
            const barH = volumeTop + volumeHeight - y;
            const barWidth = Math.max(1, (width - paddingLeft - paddingRight) / filteredData.length * 0.75);
            const isUp = d.close >= d.open;
            return (
              <rect
                key={`vol-${i}`}
                x={x - barWidth / 2}
                y={y}
                width={barWidth}
                height={Math.max(1, barH)}
                fill={isUp ? '#10B981' : '#EF4444'}
                opacity={activeIdx === i ? 1 : 0.65}
              />
            );
          })}

          {/* Hover Crosshair */}
          {activeIdx >= 0 && (
            <g>
              <line
                x1={getX(activeIdx)}
                y1={paddingTop}
                x2={getX(activeIdx)}
                y2={volumeTop + volumeHeight}
                stroke="#94A3B8"
                strokeWidth="1.2"
                strokeDasharray="3 3"
              />
              <circle
                cx={getX(activeIdx)}
                cy={getYPrice(filteredData[activeIdx].close)}
                r="4.5"
                fill="#3A86FF"
                stroke="#FFFFFF"
                strokeWidth="2"
              />
            </g>
          )}

          {/* X Axis Dates */}
          {[0, 0.25, 0.5, 0.75, 1].map((step, i) => {
            const idx = Math.min(filteredData.length - 1, Math.round(step * (filteredData.length - 1)));
            const dateStr = filteredData[idx]?.date || '';
            const x = getX(idx);
            return (
              <text
                key={`xaxis-${i}`}
                x={x}
                y={height - 5}
                fill="#94A3B8"
                fontSize="10"
                fontFamily="JetBrains Mono"
                textAnchor={i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}
              >
                {dateStr}
              </text>
            );
          })}
        </svg>
      </div>
    </div>
  );
};

// ==========================================
// ACTUAL VS PREDICTED COMPARISON CHART
// ==========================================
interface ActualVsPredictedChartProps {
  data: TestPredictionPoint[];
  height?: number;
}

export const ActualVsPredictedChart: React.FC<ActualVsPredictedChartProps> = ({ data, height = 440 }) => {
  const [hoverIndex, setHoverIndex] = useState<number | null>(null);

  if (!data.length) {
    return <div className="p-8 text-center text-slate-400">No test predictions available.</div>;
  }

  const paddingLeft = 55;
  const paddingRight = 25;
  const paddingTop = 25;
  const chartHeight = height - paddingTop - 40;
  const width = 800;

  const actuals = data.map((d) => d.actual);
  const preds = data.map((d) => d.predicted);

  const minVal = Math.min(...actuals, ...preds) * 0.96;
  const maxVal = Math.max(...actuals, ...preds) * 1.04;
  const range = maxVal - minVal || 1;

  const getX = (idx: number) => {
    const usableWidth = width - paddingLeft - paddingRight;
    return paddingLeft + (idx / (data.length - 1 || 1)) * usableWidth;
  };

  const getY = (val: number) => {
    const ratio = (val - minVal) / range;
    return paddingTop + chartHeight - ratio * chartHeight;
  };

  const actualPath = data
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i).toFixed(1)} ${getY(d.actual).toFixed(1)}`)
    .join(' ');

  const predPath = data
    .map((d, i) => `${i === 0 ? 'M' : 'L'} ${getX(i).toFixed(1)} ${getY(d.predicted).toFixed(1)}`)
    .join(' ');

  const activeIdx = hoverIndex !== null ? hoverIndex : data.length - 1;
  const activePoint = data[activeIdx];

  return (
    <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-xl">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-3 border-b border-[#2A3859]">
        <div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#10B981]"></span>
            Actual TSLA Close vs LSTM Predicted Close
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Out-of-sample chronological test period ({data.length} trading days) • Lower residual delta is better
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-1 bg-[#10B981] inline-block rounded-full"></span>
            <span className="text-emerald-400 font-bold">Actual Close</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-1 bg-[#F43F5E] inline-block border-b-2 border-dashed border-[#F43F5E]"></span>
            <span className="text-rose-400 font-bold">LSTM Predicted</span>
          </div>
        </div>
      </div>

      {/* Interactive Tooltip Card */}
      {activePoint && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-[#0B132B] p-3 rounded-lg border border-[#2A3859] mb-4 text-xs font-mono">
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Test Session</span>
            <span className="text-white font-bold">{activePoint.date}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Actual Close</span>
            <span className="text-emerald-400 font-bold text-sm">${activePoint.actual.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">LSTM Predicted</span>
            <span className="text-rose-400 font-bold text-sm">${activePoint.predicted.toFixed(2)}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Error Delta</span>
            <span className={`font-bold ${activePoint.error >= 0 ? 'text-amber-400' : 'text-cyan-400'}`}>
              {activePoint.error >= 0 ? '+' : ''}${activePoint.error.toFixed(2)}
            </span>
          </div>
          <div>
            <span className="text-slate-400 block text-[10px] uppercase">Abs % Error</span>
            <span className="text-purple-300 font-bold">{activePoint.absPctError.toFixed(2)}%</span>
          </div>
        </div>
      )}

      {/* SVG Canvas */}
      <div className="relative w-full overflow-hidden select-none">
        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-auto cursor-crosshair"
          onMouseMove={(e) => {
            const rect = e.currentTarget.getBoundingClientRect();
            const relX = ((e.clientX - rect.left) / rect.width) * width;
            const usableWidth = width - paddingLeft - paddingRight;
            const frac = Math.max(0, Math.min(1, (relX - paddingLeft) / usableWidth));
            const idx = Math.round(frac * (data.length - 1));
            setHoverIndex(idx);
          }}
          onMouseLeave={() => setHoverIndex(null)}
        >
          {/* Y Grid */}
          {[0, 0.25, 0.5, 0.75, 1].map((step, i) => {
            const y = paddingTop + chartHeight - step * chartHeight;
            const val = minVal + step * range;
            return (
              <g key={`ygrid-${i}`}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={width - paddingRight}
                  y2={y}
                  stroke="#2A3859"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={paddingLeft - 8}
                  y={y + 4}
                  fill="#94A3B8"
                  fontSize="10"
                  fontFamily="JetBrains Mono"
                  textAnchor="end"
                >
                  ${val.toFixed(0)}
                </text>
              </g>
            );
          })}

          {/* Actual Line (Green) */}
          <path d={actualPath} fill="none" stroke="#10B981" strokeWidth="2.4" strokeLinecap="round" />

          {/* Predicted Line (Rose / Dashed) */}
          <path
            d={predPath}
            fill="none"
            stroke="#F43F5E"
            strokeWidth="2.0"
            strokeDasharray="5 3"
            strokeLinecap="round"
          />

          {/* Crosshair indicator */}
          {activeIdx >= 0 && (
            <g>
              <line
                x1={getX(activeIdx)}
                y1={paddingTop}
                x2={getX(activeIdx)}
                y2={paddingTop + chartHeight}
                stroke="#94A3B8"
                strokeWidth="1.2"
                strokeDasharray="3 3"
              />
              <circle
                cx={getX(activeIdx)}
                cy={getY(data[activeIdx].actual)}
                r="4.5"
                fill="#10B981"
                stroke="#FFFFFF"
                strokeWidth="2"
              />
              <circle
                cx={getX(activeIdx)}
                cy={getY(data[activeIdx].predicted)}
                r="4.5"
                fill="#F43F5E"
                stroke="#FFFFFF"
                strokeWidth="2"
              />
            </g>
          )}

          {/* X Axis Dates */}
          {[0, 0.25, 0.5, 0.75, 1].map((step, i) => {
            const idx = Math.min(data.length - 1, Math.round(step * (data.length - 1)));
            const dateStr = data[idx]?.date || '';
            const x = getX(idx);
            return (
              <text
                key={`testx-${i}`}
                x={x}
                y={height - 10}
                fill="#94A3B8"
                fontSize="10"
                fontFamily="JetBrains Mono"
                textAnchor={i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}
              >
                {dateStr}
              </text>
            );
          })}
        </svg>
      </div>
    </div>
  );
};

// ==========================================
// TRAINING & VALIDATION LOSS CHART
// ==========================================
interface TrainingLossChartProps {
  history: TrainingHistory;
  height?: number;
}

export const TrainingLossChart: React.FC<TrainingLossChartProps> = ({ history, height = 340 }) => {
  const paddingLeft = 60;
  const paddingRight = 25;
  const paddingTop = 25;
  const chartHeight = height - paddingTop - 40;
  const width = 800;

  const epochs = history.epochs;
  const losses = history.loss;
  const valLosses = history.val_loss;

  const minLoss = 0;
  const maxLoss = Math.max(...losses, ...valLosses) * 1.1 || 0.03;

  const getX = (idx: number) => {
    const usableWidth = width - paddingLeft - paddingRight;
    return paddingLeft + (idx / (epochs.length - 1 || 1)) * usableWidth;
  };

  const getY = (val: number) => {
    const ratio = val / maxLoss;
    return paddingTop + chartHeight - ratio * chartHeight;
  };

  const lossPath = losses
    .map((l, i) => `${i === 0 ? 'M' : 'L'} ${getX(i).toFixed(1)} ${getY(l).toFixed(1)}`)
    .join(' ');

  const valLossPath = valLosses
    .map((vl, i) => `${i === 0 ? 'M' : 'L'} ${getX(i).toFixed(1)} ${getY(vl).toFixed(1)}`)
    .join(' ');

  return (
    <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-xl">
      <div className="flex items-center justify-between gap-3 mb-4 pb-3 border-b border-[#2A3859]">
        <div>
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#3A86FF]"></span>
            Learning Curve: Training Loss vs Validation Loss
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">Mean Squared Error (MSE) convergence across completed epochs</p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-1 bg-[#3A86FF] inline-block rounded-full"></span>
            <span className="text-[#3A86FF]">Train Loss ({losses[losses.length - 1]?.toFixed(5)})</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3.5 h-1 bg-[#EC4899] inline-block rounded-full"></span>
            <span className="text-[#EC4899]">Val Loss ({valLosses[valLosses.length - 1]?.toFixed(5)})</span>
          </div>
        </div>
      </div>

      <div className="relative w-full overflow-hidden">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto">
          {/* Y-axis lines */}
          {[0, 0.25, 0.5, 0.75, 1].map((step, i) => {
            const y = paddingTop + chartHeight - step * chartHeight;
            const val = step * maxLoss;
            return (
              <g key={`loss-grid-${i}`}>
                <line
                  x1={paddingLeft}
                  y1={y}
                  x2={width - paddingRight}
                  y2={y}
                  stroke="#2A3859"
                  strokeDasharray="3 3"
                  strokeWidth="1"
                />
                <text
                  x={paddingLeft - 8}
                  y={y + 4}
                  fill="#94A3B8"
                  fontSize="10"
                  fontFamily="JetBrains Mono"
                  textAnchor="end"
                >
                  {val.toFixed(4)}
                </text>
              </g>
            );
          })}

          {/* Loss lines */}
          <path d={lossPath} fill="none" stroke="#3A86FF" strokeWidth="2.4" strokeLinecap="round" />
          <path d={valLossPath} fill="none" stroke="#EC4899" strokeWidth="2.2" strokeLinecap="round" />

          {/* Epoch Labels */}
          {[0, 0.25, 0.5, 0.75, 1].map((step, i) => {
            const idx = Math.min(epochs.length - 1, Math.round(step * (epochs.length - 1)));
            const epochNum = epochs[idx];
            const x = getX(idx);
            return (
              <text
                key={`epx-${i}`}
                x={x}
                y={height - 8}
                fill="#94A3B8"
                fontSize="10"
                fontFamily="JetBrains Mono"
                textAnchor={i === 0 ? 'start' : i === 4 ? 'end' : 'middle'}
              >
                Epoch {epochNum}
              </text>
            );
          })}
        </svg>
      </div>
    </div>
  );
};

// ==========================================
// METRICS COMPARISON BAR CHART
// ==========================================
interface MetricsComparisonChartProps {
  lstmMae: number;
  lstmRmse: number;
  baseMae: number;
  baseRmse: number;
}

export const MetricsComparisonBarChart: React.FC<MetricsComparisonChartProps> = ({
  lstmMae,
  lstmRmse,
  baseMae,
  baseRmse,
}) => {
  const maxVal = Math.max(lstmMae, lstmRmse, baseMae, baseRmse) * 1.25 || 15;

  return (
    <div className="bg-[#1C2541] border border-[#2A3859] rounded-xl p-5 shadow-xl">
      <div className="mb-4 pb-3 border-b border-[#2A3859]">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-[#3A86FF]"></span>
          Quantitative Comparison: LSTM vs Naive Baseline
        </h3>
        <p className="text-xs text-slate-400 mt-0.5">
          Benchmark against Persistence Model (Tomorrow = Today) • Lower dollar error indicates superior predictive accuracy
        </p>
      </div>

      <div className="space-y-6 pt-2">
        {/* MAE Group */}
        <div>
          <div className="flex items-center justify-between text-xs font-mono mb-2">
            <span className="text-slate-300 font-bold">Mean Absolute Error (MAE)</span>
            <span className="text-emerald-400 font-bold">
              LSTM beats baseline by ${(baseMae - lstmMae).toFixed(2)} ({(((baseMae - lstmMae) / baseMae) * 100).toFixed(1)}%)
            </span>
          </div>
          <div className="space-y-2">
            <div>
              <div className="flex justify-between text-[11px] font-mono mb-1">
                <span className="text-[#3A86FF]">LSTM Deep Learning</span>
                <span className="text-white font-bold">${lstmMae.toFixed(2)}</span>
              </div>
              <div className="w-full bg-[#0B132B] h-4 rounded-full overflow-hidden border border-[#2A3859]">
                <div
                  className="bg-[#3A86FF] h-full rounded-full transition-all duration-700"
                  style={{ width: `${(lstmMae / maxVal) * 100}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[11px] font-mono mb-1">
                <span className="text-amber-400">Persistence Baseline</span>
                <span className="text-slate-300 font-bold">${baseMae.toFixed(2)}</span>
              </div>
              <div className="w-full bg-[#0B132B] h-4 rounded-full overflow-hidden border border-[#2A3859]">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all duration-700 opacity-80"
                  style={{ width: `${(baseMae / maxVal) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>

        {/* RMSE Group */}
        <div>
          <div className="flex items-center justify-between text-xs font-mono mb-2">
            <span className="text-slate-300 font-bold">Root Mean Squared Error (RMSE)</span>
            <span className="text-emerald-400 font-bold">
              LSTM beats baseline by ${(baseRmse - lstmRmse).toFixed(2)} ({(((baseRmse - lstmRmse) / baseRmse) * 100).toFixed(1)}%)
            </span>
          </div>
          <div className="space-y-2">
            <div>
              <div className="flex justify-between text-[11px] font-mono mb-1">
                <span className="text-[#3A86FF]">LSTM Deep Learning</span>
                <span className="text-white font-bold">${lstmRmse.toFixed(2)}</span>
              </div>
              <div className="w-full bg-[#0B132B] h-4 rounded-full overflow-hidden border border-[#2A3859]">
                <div
                  className="bg-[#3A86FF] h-full rounded-full transition-all duration-700"
                  style={{ width: `${(lstmRmse / maxVal) * 100}%` }}
                ></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-[11px] font-mono mb-1">
                <span className="text-amber-400">Persistence Baseline</span>
                <span className="text-slate-300 font-bold">${baseRmse.toFixed(2)}</span>
              </div>
              <div className="w-full bg-[#0B132B] h-4 rounded-full overflow-hidden border border-[#2A3859]">
                <div
                  className="bg-amber-500 h-full rounded-full transition-all duration-700 opacity-80"
                  style={{ width: `${(baseRmse / maxVal) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
