import React, { useState } from 'react';
import { UploadCloud, X, AlertCircle, CheckCircle2, FileText } from 'lucide-react';
import { StockRecord } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDataLoaded: (newData: StockRecord[]) => void;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onDataLoaded,
}) => {
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setSuccess(null);
    setIsProcessing(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        if (!text || !text.trim()) {
          throw new Error('Uploaded CSV file is empty.');
        }

        const lines = text.trim().split(/\r\n|\n/);
        if (lines.length < 2) {
          throw new Error('CSV must contain a header row and data records.');
        }

        const rawHeaders = lines[0].split(',').map((h) => h.trim().toLowerCase());
        const required = ['date', 'open', 'high', 'low', 'close', 'volume'];

        const missing = required.filter((r) => !rawHeaders.includes(r));
        if (missing.length > 0) {
          throw new Error(
            `Missing required column(s): ${missing.map((m) => m.toUpperCase()).join(', ')}. Required columns are: Date, Open, High, Low, Close, Volume.`
          );
        }

        const dateIdx = rawHeaders.indexOf('date');
        const openIdx = rawHeaders.indexOf('open');
        const highIdx = rawHeaders.indexOf('high');
        const lowIdx = rawHeaders.indexOf('low');
        const closeIdx = rawHeaders.indexOf('close');
        const volumeIdx = rawHeaders.indexOf('volume');

        const parsed: StockRecord[] = [];

        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          const cols = line.split(',');
          if (cols.length < required.length) continue;

          const dateStr = cols[dateIdx]?.trim();
          const open = parseFloat(cols[openIdx]);
          const high = parseFloat(cols[highIdx]);
          const low = parseFloat(cols[lowIdx]);
          const close = parseFloat(cols[closeIdx]);
          const volume = parseFloat(cols[volumeIdx]);

          if (dateStr && !isNaN(open) && !isNaN(high) && !isNaN(low) && !isNaN(close) && !isNaN(volume)) {
            parsed.push({
              date: dateStr,
              open: Number(open.toFixed(2)),
              high: Number(high.toFixed(2)),
              low: Number(low.toFixed(2)),
              close: Number(close.toFixed(2)),
              volume: Math.round(volume),
            });
          }
        }

        if (parsed.length < 100) {
          throw new Error(
            `Insufficient records: Found ${parsed.length} valid rows. Deep learning time-series models require at least 100 trading sessions for 70/15/15 chronological splitting.`
          );
        }

        // Deduplicate and sort chronologically
        parsed.sort((a, b) => a.date.localeCompare(b.date));
        const deduplicated: StockRecord[] = [];
        const seenDates = new Set<string>();

        for (const item of parsed) {
          if (!seenDates.has(item.date)) {
            seenDates.add(item.date);
            deduplicated.push(item);
          }
        }

        setSuccess(`Successfully validated and parsed ${deduplicated.length.toLocaleString()} historical records!`);
        setIsProcessing(false);

        setTimeout(() => {
          onDataLoaded(deduplicated);
          onClose();
        }, 800);
      } catch (err: any) {
        setIsProcessing(false);
        setError(err.message || 'Failed to process CSV file.');
      }
    };

    reader.onerror = () => {
      setIsProcessing(false);
      setError('Error reading file from disk.');
    };

    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#1C2541] border border-[#2A3859] rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#253256] transition-colors"
        >
          <X size={18} />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-[#3A86FF]">
            <UploadCloud size={20} />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Upload Custom Historical Stock Dataset</h3>
            <p className="text-xs text-slate-400">Upload TSLA CSV records to evaluate model on custom date ranges</p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Dropzone Box */}
          <label className="border-2 border-dashed border-[#2A3859] hover:border-[#3A86FF] rounded-xl p-8 flex flex-col items-center justify-center cursor-pointer transition-colors bg-[#0B132B]/50 hover:bg-[#0B132B] group">
            <input
              type="file"
              accept=".csv"
              onChange={handleFileUpload}
              className="hidden"
              disabled={isProcessing}
            />
            <FileText size={32} className="text-slate-500 group-hover:text-[#3A86FF] transition-colors mb-2" />
            <span className="text-xs font-bold text-slate-200 group-hover:text-white">
              Click to select TSLA CSV file
            </span>
            <span className="text-[11px] text-slate-500 mt-1">Supports standard Yahoo Finance CSV format</span>
          </label>

          {/* Validation Requirements Info */}
          <div className="p-3 rounded-lg bg-[#0B132B] border border-[#2A3859] text-[11px] text-slate-400 font-mono space-y-1">
            <div className="text-slate-300 font-bold uppercase text-[10px]">Required Columns:</div>
            <div>• Date (YYYY-MM-DD)</div>
            <div>• Open, High, Low, Close (Numeric USD)</div>
            <div>• Volume (Integer share count)</div>
          </div>

          {/* Error / Success Feedback */}
          {error && (
            <div className="p-3 rounded-lg bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2">
              <AlertCircle size={16} className="text-rose-400 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="p-3 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
              <span>{success}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
