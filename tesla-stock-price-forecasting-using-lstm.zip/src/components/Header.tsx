import React from 'react';
import { Download, ExternalLink, Calendar, ShieldCheck } from 'lucide-react';
import { DashboardPage } from '../types';

interface HeaderProps {
  currentPage: DashboardPage;
  latestDate: string;
  onDownloadCSV: () => void;
  onSelectPage: (page: DashboardPage) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  latestDate,
  onDownloadCSV,
  onSelectPage,
}) => {
  const pageTitles: Record<DashboardPage, { title: string; subtitle: string }> = {
    home: {
      title: 'Tesla Stock Price Forecasting Using LSTM',
      subtitle: 'Deep Learning neural architecture for sequential financial time-series prediction',
    },
    analysis: {
      title: 'Stock Market Analysis & Historical Exploration',
      subtitle: 'Tesla Inc. (TSLA) daily OHLC, volume patterns, moving averages, and distribution',
    },
    training: {
      title: 'LSTM Deep Learning Model Training',
      subtitle: '2-Layer Stacked LSTM with Adam optimizer, early stopping, and checkpointing',
    },
    prediction: {
      title: 'Next Trading Day Stock Price Forecast',
      subtitle: 'Inference pipeline utilizing rolling 60-day historical trading sessions',
    },
    comparison: {
      title: 'Actual vs LSTM Predicted Comparison',
      subtitle: 'Chronological test-set out-of-sample ground truth vs neural predictions',
    },
    performance: {
      title: 'Model Performance & Quantitative Evaluation',
      subtitle: 'MAE, MSE, RMSE error benchmarks against Naive Persistence Baseline',
    },
    about: {
      title: 'Project Architecture, Theory & Documentation',
      subtitle: 'Complete technical breakdown, mathematics, limitations, and future roadmap',
    },
    codebase: {
      title: 'Python Source Code & Modular Files',
      subtitle: 'Browse, inspect, and copy production Python modules and test suites',
    },
  };

  const info = pageTitles[currentPage];

  return (
    <header className="bg-[#1C2541]/90 backdrop-blur-md border-b border-[#2A3859] px-6 py-4 sticky top-0 z-20 flex flex-wrap items-center justify-between gap-4">
      <div>
        <div className="flex items-center gap-2 text-xs font-mono text-[#3A86FF]">
          <span>PROJECT TSLA-LSTM</span>
          <span>•</span>
          <span className="uppercase text-slate-300 font-semibold">{currentPage}</span>
        </div>
        <h2 className="text-xl font-bold text-white tracking-tight mt-0.5">{info.title}</h2>
        <p className="text-xs text-slate-400">{info.subtitle}</p>
      </div>

      <div className="flex items-center gap-3">
        {/* Latest Market Date Indicator */}
        <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0B132B] border border-[#2A3859] text-xs font-mono">
          <Calendar size={13} className="text-[#3A86FF]" />
          <span className="text-slate-400">Market Date:</span>
          <span className="text-white font-bold">{latestDate}</span>
        </div>

        {/* Verification Shield */}
        <div className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono font-medium">
          <ShieldCheck size={14} />
          <span>Zero Data Leakage</span>
        </div>

        {/* Download CSV Action */}
        <button
          onClick={onDownloadCSV}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0B132B] hover:bg-[#2A3859] text-slate-200 text-xs font-medium border border-[#2A3859] transition-colors"
          title="Download historical TSLA dataset as CSV"
        >
          <Download size={14} className="text-[#3A86FF]" />
          <span className="hidden sm:inline">Export</span> CSV
        </button>
      </div>
    </header>
  );
};
